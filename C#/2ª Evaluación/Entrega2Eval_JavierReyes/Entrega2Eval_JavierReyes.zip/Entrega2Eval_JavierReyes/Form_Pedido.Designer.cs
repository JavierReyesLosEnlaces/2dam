﻿namespace Entrega2Eval_JavierReyes
{
    partial class Form_Pedido
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Pedido));
            tlp1 = new TableLayoutPanel();
            lbl_banner = new Label();
            tlp2 = new TableLayoutPanel();
            panelDerecho1 = new Panel();
            tlp8 = new TableLayoutPanel();
            tlp10 = new TableLayoutPanel();
            label2 = new Label();
            tlp15 = new TableLayoutPanel();
            pro1 = new Label();
            pre1 = new Label();
            pro2 = new Label();
            pre2 = new Label();
            pro3 = new Label();
            pre3 = new Label();
            pro1Extras = new Label();
            pre1Extras = new Label();
            pro3Extras = new Label();
            pre3Extras = new Label();
            tlp9 = new TableLayoutPanel();
            lbl_descripcionTitulo = new Label();
            lbl_descripcion = new Label();
            tlp4 = new TableLayoutPanel();
            panelIzquierdo2 = new Panel();
            tlp5 = new TableLayoutPanel();
            tlpExtras = new TableLayoutPanel();
            btnExtras = new Button();
            lbl_añadirExtras = new Label();
            tlpProducto2 = new TableLayoutPanel();
            btnProducto2 = new Button();
            tlp7 = new TableLayoutPanel();
            lbl_precioProducto2 = new Label();
            lbl_nombreProducto2 = new Label();
            tlpProducto1 = new TableLayoutPanel();
            tlp6 = new TableLayoutPanel();
            lbl_precioProducto1 = new Label();
            lbl_nombreProducto1 = new Label();
            btnProducto1 = new Button();
            lbl_tipoProducto = new Label();
            tlp3 = new TableLayoutPanel();
            lbl_total2 = new Label();
            lbl_total1 = new Label();
            tlp14 = new TableLayoutPanel();
            btn_añadirPagar = new Button();
            btn_cancelar = new Button();
            tlp16 = new TableLayoutPanel();
            tlp11 = new TableLayoutPanel();
            label9 = new Label();
            label10 = new Label();
            button4 = new Button();
            tlp12 = new TableLayoutPanel();
            tlp13 = new TableLayoutPanel();
            label11 = new Label();
            label12 = new Label();
            button5 = new Button();
            userControl1 = new UserControl_MenuExtras();
            userControl2 = new UserControl_QuitamosAlgo();
            userControl3 = new UserControl_UltimosDetalles();
            userControl4 = new UserControl_MostrarFacturas();
            tlp1.SuspendLayout();
            tlp2.SuspendLayout();
            panelDerecho1.SuspendLayout();
            tlp8.SuspendLayout();
            tlp10.SuspendLayout();
            tlp15.SuspendLayout();
            tlp9.SuspendLayout();
            tlp4.SuspendLayout();
            panelIzquierdo2.SuspendLayout();
            tlp5.SuspendLayout();
            tlpExtras.SuspendLayout();
            tlpProducto2.SuspendLayout();
            tlp7.SuspendLayout();
            tlpProducto1.SuspendLayout();
            tlp6.SuspendLayout();
            tlp3.SuspendLayout();
            tlp14.SuspendLayout();
            tlp16.SuspendLayout();
            tlp11.SuspendLayout();
            tlp12.SuspendLayout();
            tlp13.SuspendLayout();
            SuspendLayout();
            // 
            // tlp1
            // 
            tlp1.BackColor = SystemColors.ActiveCaption;
            tlp1.BackgroundImage = (Image)resources.GetObject("tlp1.BackgroundImage");
            tlp1.BackgroundImageLayout = ImageLayout.Stretch;
            tlp1.ColumnCount = 1;
            tlp1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlp1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 21F));
            tlp1.Controls.Add(lbl_banner, 0, 1);
            tlp1.ForeColor = Color.Transparent;
            tlp1.Location = new Point(0, -1);
            tlp1.Name = "tlp1";
            tlp1.RowCount = 2;
            tlp1.RowStyles.Add(new RowStyle(SizeType.Percent, 70F));
            tlp1.RowStyles.Add(new RowStyle(SizeType.Percent, 30F));
            tlp1.Size = new Size(811, 207);
            tlp1.TabIndex = 4;
            // 
            // lbl_banner
            // 
            lbl_banner.AutoSize = true;
            lbl_banner.BackColor = Color.Black;
            lbl_banner.Dock = DockStyle.Fill;
            lbl_banner.Font = new Font("Jokerman", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_banner.ForeColor = Color.White;
            lbl_banner.Location = new Point(0, 144);
            lbl_banner.Margin = new Padding(0);
            lbl_banner.Name = "lbl_banner";
            lbl_banner.Size = new Size(811, 63);
            lbl_banner.TabIndex = 1;
            lbl_banner.Text = "Hamburguesería 'Los Enlaces'";
            lbl_banner.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // tlp2
            // 
            tlp2.BackColor = Color.Transparent;
            tlp2.ColumnCount = 2;
            tlp2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 60F));
            tlp2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40F));
            tlp2.Controls.Add(panelDerecho1, 1, 0);
            tlp2.Controls.Add(tlp4, 0, 0);
            tlp2.Controls.Add(tlp3, 1, 1);
            tlp2.Controls.Add(tlp14, 0, 1);
            tlp2.Location = new Point(11, 219);
            tlp2.Margin = new Padding(0);
            tlp2.Name = "tlp2";
            tlp2.RowCount = 2;
            tlp2.RowStyles.Add(new RowStyle(SizeType.Percent, 90F));
            tlp2.RowStyles.Add(new RowStyle(SizeType.Percent, 10F));
            tlp2.Size = new Size(791, 632);
            tlp2.TabIndex = 5;
            // 
            // panelDerecho1
            // 
            panelDerecho1.BackColor = Color.FromArgb(250, 234, 221);
            panelDerecho1.Controls.Add(tlp8);
            panelDerecho1.Font = new Font("Segoe UI", 9F);
            panelDerecho1.Location = new Point(484, 0);
            panelDerecho1.Margin = new Padding(10, 0, 0, 0);
            panelDerecho1.Name = "panelDerecho1";
            panelDerecho1.Size = new Size(306, 568);
            panelDerecho1.TabIndex = 0;
            // 
            // tlp8
            // 
            tlp8.BackColor = Color.FromArgb(80, 34, 18);
            tlp8.ColumnCount = 1;
            tlp8.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlp8.Controls.Add(tlp10, 0, 1);
            tlp8.Controls.Add(tlp9, 0, 0);
            tlp8.Dock = DockStyle.Fill;
            tlp8.Location = new Point(0, 0);
            tlp8.Name = "tlp8";
            tlp8.RowCount = 2;
            tlp8.RowStyles.Add(new RowStyle(SizeType.Percent, 30F));
            tlp8.RowStyles.Add(new RowStyle(SizeType.Percent, 70F));
            tlp8.Size = new Size(306, 568);
            tlp8.TabIndex = 0;
            // 
            // tlp10
            // 
            tlp10.ColumnCount = 1;
            tlp10.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlp10.Controls.Add(label2, 0, 0);
            tlp10.Controls.Add(tlp15, 0, 1);
            tlp10.Dock = DockStyle.Fill;
            tlp10.Location = new Point(3, 173);
            tlp10.Margin = new Padding(3, 3, 5, 0);
            tlp10.Name = "tlp10";
            tlp10.RowCount = 2;
            tlp10.RowStyles.Add(new RowStyle(SizeType.Percent, 13F));
            tlp10.RowStyles.Add(new RowStyle(SizeType.Percent, 87F));
            tlp10.Size = new Size(298, 395);
            tlp10.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.FromArgb(255, 217, 193);
            label2.Dock = DockStyle.Fill;
            label2.Font = new Font("Ink Free", 14F, FontStyle.Bold);
            label2.Location = new Point(3, 0);
            label2.Margin = new Padding(3, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(293, 51);
            label2.TabIndex = 1;
            label2.Text = "Pedido";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // tlp15
            // 
            tlp15.BackColor = Color.FromArgb(255, 249, 244);
            tlp15.ColumnCount = 2;
            tlp15.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 64.35644F));
            tlp15.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 35.6435661F));
            tlp15.Controls.Add(pro1, 0, 0);
            tlp15.Controls.Add(pre1, 1, 0);
            tlp15.Controls.Add(pro2, 0, 2);
            tlp15.Controls.Add(pre2, 1, 2);
            tlp15.Controls.Add(pro3, 0, 3);
            tlp15.Controls.Add(pre3, 1, 3);
            tlp15.Controls.Add(pro1Extras, 0, 1);
            tlp15.Controls.Add(pre1Extras, 1, 1);
            tlp15.Controls.Add(pro3Extras, 0, 4);
            tlp15.Controls.Add(pre3Extras, 1, 4);
            tlp15.Location = new Point(3, 51);
            tlp15.Margin = new Padding(3, 0, 0, 3);
            tlp15.Name = "tlp15";
            tlp15.RowCount = 5;
            tlp15.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tlp15.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tlp15.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tlp15.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tlp15.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tlp15.Size = new Size(293, 339);
            tlp15.TabIndex = 2;
            // 
            // pro1
            // 
            pro1.AutoSize = true;
            pro1.BackColor = Color.FromArgb(255, 249, 244);
            pro1.Dock = DockStyle.Fill;
            pro1.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            pro1.Location = new Point(0, 0);
            pro1.Margin = new Padding(0);
            pro1.Name = "pro1";
            pro1.Padding = new Padding(10, 0, 0, 0);
            pro1.Size = new Size(188, 67);
            pro1.TabIndex = 0;
            pro1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pre1
            // 
            pre1.AutoSize = true;
            pre1.Dock = DockStyle.Fill;
            pre1.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            pre1.Location = new Point(188, 0);
            pre1.Margin = new Padding(0);
            pre1.Name = "pre1";
            pre1.Size = new Size(105, 67);
            pre1.TabIndex = 1;
            pre1.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // pro2
            // 
            pro2.AutoSize = true;
            pro2.Dock = DockStyle.Fill;
            pro2.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            pro2.Location = new Point(0, 134);
            pro2.Margin = new Padding(0);
            pro2.Name = "pro2";
            pro2.Padding = new Padding(10, 0, 0, 0);
            pro2.Size = new Size(188, 67);
            pro2.TabIndex = 2;
            pro2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pre2
            // 
            pre2.AutoSize = true;
            pre2.Dock = DockStyle.Fill;
            pre2.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            pre2.Location = new Point(188, 134);
            pre2.Margin = new Padding(0);
            pre2.Name = "pre2";
            pre2.Size = new Size(105, 67);
            pre2.TabIndex = 3;
            pre2.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // pro3
            // 
            pro3.AutoSize = true;
            pro3.Dock = DockStyle.Fill;
            pro3.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            pro3.Location = new Point(0, 201);
            pro3.Margin = new Padding(0);
            pro3.Name = "pro3";
            pro3.Padding = new Padding(10, 0, 0, 0);
            pro3.Size = new Size(188, 67);
            pro3.TabIndex = 4;
            pro3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pre3
            // 
            pre3.AutoSize = true;
            pre3.Dock = DockStyle.Fill;
            pre3.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            pre3.Location = new Point(188, 201);
            pre3.Margin = new Padding(0);
            pre3.Name = "pre3";
            pre3.Size = new Size(105, 67);
            pre3.TabIndex = 5;
            pre3.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // pro1Extras
            // 
            pro1Extras.AutoSize = true;
            pro1Extras.BackColor = Color.FromArgb(255, 249, 244);
            pro1Extras.Dock = DockStyle.Fill;
            pro1Extras.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            pro1Extras.ForeColor = Color.FromArgb(29, 171, 71);
            pro1Extras.Location = new Point(0, 67);
            pro1Extras.Margin = new Padding(0);
            pro1Extras.Name = "pro1Extras";
            pro1Extras.Padding = new Padding(10, 0, 0, 0);
            pro1Extras.Size = new Size(188, 67);
            pro1Extras.TabIndex = 6;
            pro1Extras.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pre1Extras
            // 
            pre1Extras.AutoSize = true;
            pre1Extras.BackColor = Color.FromArgb(255, 249, 244);
            pre1Extras.Dock = DockStyle.Fill;
            pre1Extras.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            pre1Extras.ForeColor = Color.FromArgb(29, 171, 71);
            pre1Extras.Location = new Point(188, 67);
            pre1Extras.Margin = new Padding(0);
            pre1Extras.Name = "pre1Extras";
            pre1Extras.Size = new Size(105, 67);
            pre1Extras.TabIndex = 7;
            pre1Extras.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // pro3Extras
            // 
            pro3Extras.AutoSize = true;
            pro3Extras.BackColor = Color.FromArgb(255, 249, 244);
            pro3Extras.Dock = DockStyle.Fill;
            pro3Extras.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            pro3Extras.ForeColor = Color.FromArgb(29, 171, 71);
            pro3Extras.Location = new Point(0, 268);
            pro3Extras.Margin = new Padding(0);
            pro3Extras.Name = "pro3Extras";
            pro3Extras.Padding = new Padding(10, 0, 0, 0);
            pro3Extras.Size = new Size(188, 71);
            pro3Extras.TabIndex = 8;
            pro3Extras.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pre3Extras
            // 
            pre3Extras.AutoSize = true;
            pre3Extras.BackColor = Color.FromArgb(255, 249, 244);
            pre3Extras.Dock = DockStyle.Fill;
            pre3Extras.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            pre3Extras.ForeColor = Color.FromArgb(29, 171, 71);
            pre3Extras.Location = new Point(188, 268);
            pre3Extras.Margin = new Padding(0);
            pre3Extras.Name = "pre3Extras";
            pre3Extras.Size = new Size(105, 71);
            pre3Extras.TabIndex = 9;
            pre3Extras.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // tlp9
            // 
            tlp9.ColumnCount = 1;
            tlp9.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlp9.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 21F));
            tlp9.Controls.Add(lbl_descripcionTitulo, 0, 0);
            tlp9.Controls.Add(lbl_descripcion, 0, 1);
            tlp9.Dock = DockStyle.Fill;
            tlp9.Location = new Point(3, 3);
            tlp9.Name = "tlp9";
            tlp9.RowCount = 2;
            tlp9.RowStyles.Add(new RowStyle(SizeType.Percent, 30F));
            tlp9.RowStyles.Add(new RowStyle(SizeType.Percent, 70F));
            tlp9.Size = new Size(300, 164);
            tlp9.TabIndex = 0;
            // 
            // lbl_descripcionTitulo
            // 
            lbl_descripcionTitulo.AutoSize = true;
            lbl_descripcionTitulo.BackColor = Color.FromArgb(22, 134, 55);
            lbl_descripcionTitulo.Dock = DockStyle.Fill;
            lbl_descripcionTitulo.Font = new Font("Ink Free", 14F, FontStyle.Bold);
            lbl_descripcionTitulo.ForeColor = SystemColors.ButtonHighlight;
            lbl_descripcionTitulo.Location = new Point(3, 0);
            lbl_descripcionTitulo.Name = "lbl_descripcionTitulo";
            lbl_descripcionTitulo.Size = new Size(294, 49);
            lbl_descripcionTitulo.TabIndex = 0;
            lbl_descripcionTitulo.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbl_descripcion
            // 
            lbl_descripcion.AutoSize = true;
            lbl_descripcion.BackColor = Color.FromArgb(29, 171, 71);
            lbl_descripcion.Dock = DockStyle.Fill;
            lbl_descripcion.Font = new Font("Ink Free", 10F, FontStyle.Bold);
            lbl_descripcion.ForeColor = SystemColors.ButtonHighlight;
            lbl_descripcion.Location = new Point(3, 49);
            lbl_descripcion.Name = "lbl_descripcion";
            lbl_descripcion.Padding = new Padding(5);
            lbl_descripcion.Size = new Size(294, 115);
            lbl_descripcion.TabIndex = 1;
            // 
            // tlp4
            // 
            tlp4.ColumnCount = 1;
            tlp4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlp4.Controls.Add(panelIzquierdo2, 0, 1);
            tlp4.Controls.Add(lbl_tipoProducto, 0, 0);
            tlp4.Location = new Point(0, 0);
            tlp4.Margin = new Padding(0);
            tlp4.Name = "tlp4";
            tlp4.RowCount = 2;
            tlp4.RowStyles.Add(new RowStyle(SizeType.Percent, 10F));
            tlp4.RowStyles.Add(new RowStyle(SizeType.Percent, 90F));
            tlp4.Size = new Size(474, 568);
            tlp4.TabIndex = 2;
            // 
            // panelIzquierdo2
            // 
            panelIzquierdo2.BackColor = Color.IndianRed;
            panelIzquierdo2.Controls.Add(tlp5);
            panelIzquierdo2.Location = new Point(0, 56);
            panelIzquierdo2.Margin = new Padding(0);
            panelIzquierdo2.Name = "panelIzquierdo2";
            panelIzquierdo2.Size = new Size(474, 512);
            panelIzquierdo2.TabIndex = 1;
            // 
            // tlp5
            // 
            tlp5.BackColor = Color.FromArgb(255, 152, 83);
            tlp5.ColumnCount = 2;
            tlp5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tlp5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tlp5.Controls.Add(tlpExtras, 0, 1);
            tlp5.Controls.Add(tlpProducto2, 1, 0);
            tlp5.Controls.Add(tlpProducto1, 0, 0);
            tlp5.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            tlp5.Location = new Point(0, 0);
            tlp5.Margin = new Padding(0);
            tlp5.Name = "tlp5";
            tlp5.RowCount = 2;
            tlp5.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tlp5.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tlp5.Size = new Size(474, 513);
            tlp5.TabIndex = 0;
            // 
            // tlpExtras
            // 
            tlpExtras.ColumnCount = 1;
            tlpExtras.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlpExtras.Controls.Add(btnExtras, 0, 0);
            tlpExtras.Controls.Add(lbl_añadirExtras, 0, 1);
            tlpExtras.Dock = DockStyle.Fill;
            tlpExtras.Location = new Point(3, 259);
            tlpExtras.Name = "tlpExtras";
            tlpExtras.RowCount = 2;
            tlpExtras.RowStyles.Add(new RowStyle(SizeType.Percent, 90F));
            tlpExtras.RowStyles.Add(new RowStyle(SizeType.Percent, 10F));
            tlpExtras.Size = new Size(231, 251);
            tlpExtras.TabIndex = 7;
            // 
            // btnExtras
            // 
            btnExtras.BackColor = Color.Transparent;
            btnExtras.BackgroundImageLayout = ImageLayout.Stretch;
            btnExtras.Dock = DockStyle.Fill;
            btnExtras.FlatAppearance.BorderSize = 3;
            btnExtras.FlatStyle = FlatStyle.Popup;
            btnExtras.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnExtras.ForeColor = SystemColors.ButtonHighlight;
            btnExtras.Location = new Point(15, 15);
            btnExtras.Margin = new Padding(15);
            btnExtras.Name = "btnExtras";
            btnExtras.Size = new Size(201, 195);
            btnExtras.TabIndex = 6;
            btnExtras.UseVisualStyleBackColor = false;
            btnExtras.Click += btnExtras_Click;
            // 
            // lbl_añadirExtras
            // 
            lbl_añadirExtras.AutoSize = true;
            lbl_añadirExtras.BackColor = Color.Black;
            lbl_añadirExtras.Dock = DockStyle.Fill;
            lbl_añadirExtras.Font = new Font("Ink Free", 10F, FontStyle.Bold);
            lbl_añadirExtras.ForeColor = SystemColors.ButtonHighlight;
            lbl_añadirExtras.Location = new Point(3, 225);
            lbl_añadirExtras.Margin = new Padding(3, 0, 3, 3);
            lbl_añadirExtras.Name = "lbl_añadirExtras";
            lbl_añadirExtras.Size = new Size(225, 23);
            lbl_añadirExtras.TabIndex = 7;
            lbl_añadirExtras.Text = "Añadir extras";
            lbl_añadirExtras.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // tlpProducto2
            // 
            tlpProducto2.ColumnCount = 1;
            tlpProducto2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlpProducto2.Controls.Add(btnProducto2, 0, 0);
            tlpProducto2.Controls.Add(tlp7, 0, 1);
            tlpProducto2.Dock = DockStyle.Fill;
            tlpProducto2.ForeColor = SystemColors.ControlText;
            tlpProducto2.Location = new Point(237, 0);
            tlpProducto2.Margin = new Padding(0);
            tlpProducto2.Name = "tlpProducto2";
            tlpProducto2.RowCount = 2;
            tlpProducto2.RowStyles.Add(new RowStyle(SizeType.Percent, 90F));
            tlpProducto2.RowStyles.Add(new RowStyle(SizeType.Percent, 10F));
            tlpProducto2.Size = new Size(237, 256);
            tlpProducto2.TabIndex = 3;
            // 
            // btnProducto2
            // 
            btnProducto2.BackColor = Color.Transparent;
            btnProducto2.BackgroundImageLayout = ImageLayout.Stretch;
            btnProducto2.Dock = DockStyle.Fill;
            btnProducto2.FlatAppearance.BorderColor = Color.FromArgb(214, 34, 0);
            btnProducto2.FlatAppearance.BorderSize = 0;
            btnProducto2.FlatStyle = FlatStyle.Popup;
            btnProducto2.Location = new Point(15, 15);
            btnProducto2.Margin = new Padding(15);
            btnProducto2.Name = "btnProducto2";
            btnProducto2.Size = new Size(207, 200);
            btnProducto2.TabIndex = 4;
            btnProducto2.UseVisualStyleBackColor = false;
            btnProducto2.Click += btnProducto2_Click;
            // 
            // tlp7
            // 
            tlp7.BackColor = Color.Black;
            tlp7.ColumnCount = 2;
            tlp7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tlp7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tlp7.Controls.Add(lbl_precioProducto2, 0, 0);
            tlp7.Controls.Add(lbl_nombreProducto2, 0, 0);
            tlp7.Location = new Point(3, 233);
            tlp7.Name = "tlp7";
            tlp7.RowCount = 1;
            tlp7.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tlp7.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tlp7.Size = new Size(231, 20);
            tlp7.TabIndex = 5;
            // 
            // lbl_precioProducto2
            // 
            lbl_precioProducto2.AutoSize = true;
            lbl_precioProducto2.BackColor = Color.Transparent;
            lbl_precioProducto2.Dock = DockStyle.Fill;
            lbl_precioProducto2.Font = new Font("Ink Free", 10F, FontStyle.Bold);
            lbl_precioProducto2.ForeColor = SystemColors.ButtonHighlight;
            lbl_precioProducto2.Location = new Point(118, 0);
            lbl_precioProducto2.Name = "lbl_precioProducto2";
            lbl_precioProducto2.Size = new Size(110, 20);
            lbl_precioProducto2.TabIndex = 2;
            lbl_precioProducto2.Text = "Precio2";
            lbl_precioProducto2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbl_nombreProducto2
            // 
            lbl_nombreProducto2.AutoSize = true;
            lbl_nombreProducto2.BackColor = Color.Transparent;
            lbl_nombreProducto2.Dock = DockStyle.Fill;
            lbl_nombreProducto2.Font = new Font("Ink Free", 10F, FontStyle.Bold);
            lbl_nombreProducto2.ForeColor = SystemColors.ButtonHighlight;
            lbl_nombreProducto2.Location = new Point(3, 0);
            lbl_nombreProducto2.Name = "lbl_nombreProducto2";
            lbl_nombreProducto2.Size = new Size(109, 20);
            lbl_nombreProducto2.TabIndex = 1;
            lbl_nombreProducto2.Text = "Producto2";
            lbl_nombreProducto2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // tlpProducto1
            // 
            tlpProducto1.ColumnCount = 1;
            tlpProducto1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlpProducto1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 21F));
            tlpProducto1.Controls.Add(tlp6, 0, 1);
            tlpProducto1.Controls.Add(btnProducto1, 0, 0);
            tlpProducto1.Location = new Point(0, 0);
            tlpProducto1.Margin = new Padding(0);
            tlpProducto1.Name = "tlpProducto1";
            tlpProducto1.RowCount = 2;
            tlpProducto1.RowStyles.Add(new RowStyle(SizeType.Percent, 90F));
            tlpProducto1.RowStyles.Add(new RowStyle(SizeType.Percent, 10F));
            tlpProducto1.Size = new Size(237, 256);
            tlpProducto1.TabIndex = 4;
            // 
            // tlp6
            // 
            tlp6.BackColor = Color.Black;
            tlp6.ColumnCount = 2;
            tlp6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tlp6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tlp6.Controls.Add(lbl_precioProducto1, 1, 0);
            tlp6.Controls.Add(lbl_nombreProducto1, 0, 0);
            tlp6.Location = new Point(3, 233);
            tlp6.Name = "tlp6";
            tlp6.RowCount = 1;
            tlp6.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tlp6.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tlp6.Size = new Size(230, 20);
            tlp6.TabIndex = 6;
            // 
            // lbl_precioProducto1
            // 
            lbl_precioProducto1.AutoSize = true;
            lbl_precioProducto1.BackColor = Color.Transparent;
            lbl_precioProducto1.Dock = DockStyle.Fill;
            lbl_precioProducto1.Font = new Font("Ink Free", 10F, FontStyle.Bold);
            lbl_precioProducto1.ForeColor = SystemColors.ButtonHighlight;
            lbl_precioProducto1.Location = new Point(118, 0);
            lbl_precioProducto1.Name = "lbl_precioProducto1";
            lbl_precioProducto1.Size = new Size(109, 20);
            lbl_precioProducto1.TabIndex = 1;
            lbl_precioProducto1.Text = "Precio1";
            lbl_precioProducto1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lbl_nombreProducto1
            // 
            lbl_nombreProducto1.AutoSize = true;
            lbl_nombreProducto1.BackColor = Color.Transparent;
            lbl_nombreProducto1.Dock = DockStyle.Fill;
            lbl_nombreProducto1.Font = new Font("Ink Free", 10F, FontStyle.Bold);
            lbl_nombreProducto1.ForeColor = SystemColors.ButtonHighlight;
            lbl_nombreProducto1.Location = new Point(3, 0);
            lbl_nombreProducto1.Name = "lbl_nombreProducto1";
            lbl_nombreProducto1.Size = new Size(109, 20);
            lbl_nombreProducto1.TabIndex = 0;
            lbl_nombreProducto1.Text = "Producto1";
            lbl_nombreProducto1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // btnProducto1
            // 
            btnProducto1.BackColor = Color.Transparent;
            btnProducto1.BackgroundImageLayout = ImageLayout.Stretch;
            btnProducto1.Dock = DockStyle.Fill;
            btnProducto1.FlatAppearance.BorderColor = Color.FromArgb(214, 34, 0);
            btnProducto1.FlatAppearance.BorderSize = 0;
            btnProducto1.FlatStyle = FlatStyle.Popup;
            btnProducto1.Location = new Point(15, 15);
            btnProducto1.Margin = new Padding(15);
            btnProducto1.Name = "btnProducto1";
            btnProducto1.Size = new Size(207, 200);
            btnProducto1.TabIndex = 2;
            btnProducto1.UseVisualStyleBackColor = false;
            btnProducto1.Click += btnProducto1_Click;
            // 
            // lbl_tipoProducto
            // 
            lbl_tipoProducto.AutoSize = true;
            lbl_tipoProducto.BackColor = Color.FromArgb(255, 134, 50);
            lbl_tipoProducto.Dock = DockStyle.Fill;
            lbl_tipoProducto.Font = new Font("Ink Free", 22F, FontStyle.Bold);
            lbl_tipoProducto.Location = new Point(0, 0);
            lbl_tipoProducto.Margin = new Padding(0);
            lbl_tipoProducto.Name = "lbl_tipoProducto";
            lbl_tipoProducto.Size = new Size(474, 56);
            lbl_tipoProducto.TabIndex = 2;
            lbl_tipoProducto.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // tlp3
            // 
            tlp3.ColumnCount = 2;
            tlp3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 66.6666641F));
            tlp3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333321F));
            tlp3.Controls.Add(lbl_total2, 1, 0);
            tlp3.Controls.Add(lbl_total1, 0, 0);
            tlp3.Location = new Point(481, 575);
            tlp3.Margin = new Padding(7);
            tlp3.Name = "tlp3";
            tlp3.RowCount = 1;
            tlp3.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tlp3.Size = new Size(302, 49);
            tlp3.TabIndex = 4;
            // 
            // lbl_total2
            // 
            lbl_total2.AutoSize = true;
            lbl_total2.Dock = DockStyle.Fill;
            lbl_total2.Font = new Font("Ink Free", 15F, FontStyle.Bold);
            lbl_total2.ForeColor = SystemColors.Window;
            lbl_total2.Location = new Point(204, 0);
            lbl_total2.Name = "lbl_total2";
            lbl_total2.Size = new Size(95, 49);
            lbl_total2.TabIndex = 1;
            lbl_total2.Text = "-";
            lbl_total2.TextAlign = ContentAlignment.MiddleLeft;
            lbl_total2.Visible = false;
            // 
            // lbl_total1
            // 
            lbl_total1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            lbl_total1.AutoSize = true;
            lbl_total1.Font = new Font("Ink Free", 15F, FontStyle.Bold);
            lbl_total1.ForeColor = SystemColors.ButtonHighlight;
            lbl_total1.Location = new Point(3, 0);
            lbl_total1.Name = "lbl_total1";
            lbl_total1.Size = new Size(195, 49);
            lbl_total1.TabIndex = 0;
            lbl_total1.Text = "Total:";
            lbl_total1.TextAlign = ContentAlignment.MiddleCenter;
            lbl_total1.Visible = false;
            // 
            // tlp14
            // 
            tlp14.ColumnCount = 2;
            tlp14.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 80F));
            tlp14.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tlp14.Controls.Add(btn_añadirPagar, 0, 0);
            tlp14.Controls.Add(btn_cancelar, 1, 0);
            tlp14.Dock = DockStyle.Fill;
            tlp14.Location = new Point(0, 568);
            tlp14.Margin = new Padding(0);
            tlp14.Name = "tlp14";
            tlp14.RowCount = 1;
            tlp14.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tlp14.Size = new Size(474, 64);
            tlp14.TabIndex = 5;
            // 
            // btn_añadirPagar
            // 
            btn_añadirPagar.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            btn_añadirPagar.BackColor = Color.FromArgb(22, 134, 55);
            btn_añadirPagar.FlatAppearance.BorderColor = Color.FromArgb(22, 134, 55);
            btn_añadirPagar.FlatAppearance.BorderSize = 0;
            btn_añadirPagar.FlatStyle = FlatStyle.Popup;
            btn_añadirPagar.Font = new Font("Ink Free", 13F, FontStyle.Bold);
            btn_añadirPagar.ForeColor = Color.FromArgb(245, 235, 220);
            btn_añadirPagar.Location = new Point(39, 11);
            btn_añadirPagar.Margin = new Padding(0, 11, 0, 0);
            btn_añadirPagar.Name = "btn_añadirPagar";
            btn_añadirPagar.Size = new Size(301, 53);
            btn_añadirPagar.TabIndex = 4;
            btn_añadirPagar.UseVisualStyleBackColor = false;
            btn_añadirPagar.Click += btn_añadirPagar_Click;
            // 
            // btn_cancelar
            // 
            btn_cancelar.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            btn_cancelar.BackColor = Color.Red;
            btn_cancelar.FlatStyle = FlatStyle.Flat;
            btn_cancelar.Font = new Font("Malgun Gothic", 14F, FontStyle.Bold);
            btn_cancelar.ForeColor = Color.White;
            btn_cancelar.Location = new Point(379, 11);
            btn_cancelar.Margin = new Padding(0, 11, 34, 0);
            btn_cancelar.Name = "btn_cancelar";
            btn_cancelar.Size = new Size(61, 53);
            btn_cancelar.TabIndex = 5;
            btn_cancelar.Text = "X";
            btn_cancelar.UseVisualStyleBackColor = false;
            btn_cancelar.Click += btnCancelar_Click;
            // 
            // tlp16
            // 
            tlp16.ColumnCount = 1;
            tlp16.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlp16.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 18F));
            tlp16.Controls.Add(tlp11, 0, 1);
            tlp16.Location = new Point(0, 0);
            tlp16.Margin = new Padding(0);
            tlp16.Name = "tlp16";
            tlp16.RowCount = 2;
            tlp16.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tlp16.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tlp16.Size = new Size(200, 100);
            tlp16.TabIndex = 0;
            // 
            // tlp11
            // 
            tlp11.BackColor = Color.Black;
            tlp11.ColumnCount = 2;
            tlp11.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tlp11.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tlp11.Controls.Add(label9, 1, 0);
            tlp11.Controls.Add(label10, 0, 0);
            tlp11.Location = new Point(3, 22);
            tlp11.Margin = new Padding(3, 2, 3, 2);
            tlp11.Name = "tlp11";
            tlp11.RowCount = 1;
            tlp11.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tlp11.RowStyles.Add(new RowStyle(SizeType.Absolute, 15F));
            tlp11.Size = new Size(194, 15);
            tlp11.TabIndex = 6;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Dock = DockStyle.Fill;
            label9.Font = new Font("Ink Free", 10F, FontStyle.Bold);
            label9.ForeColor = SystemColors.ButtonHighlight;
            label9.Location = new Point(100, 0);
            label9.Name = "label9";
            label9.Size = new Size(91, 15);
            label9.TabIndex = 1;
            label9.Text = "Precio1";
            label9.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Dock = DockStyle.Fill;
            label10.Font = new Font("Ink Free", 10F, FontStyle.Bold);
            label10.ForeColor = SystemColors.ButtonHighlight;
            label10.Location = new Point(3, 0);
            label10.Name = "label10";
            label10.Size = new Size(91, 15);
            label10.TabIndex = 0;
            label10.Text = "Producto1";
            label10.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // button4
            // 
            button4.BackColor = Color.Transparent;
            button4.BackgroundImageLayout = ImageLayout.None;
            button4.Dock = DockStyle.Fill;
            button4.FlatAppearance.BorderColor = Color.FromArgb(214, 34, 0);
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatStyle = FlatStyle.Popup;
            button4.Location = new Point(13, 11);
            button4.Margin = new Padding(13, 11, 13, 11);
            button4.Name = "button4";
            button4.Size = new Size(174, 150);
            button4.TabIndex = 2;
            button4.UseVisualStyleBackColor = false;
            // 
            // tlp12
            // 
            tlp12.ColumnCount = 1;
            tlp12.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlp12.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 18F));
            tlp12.Controls.Add(tlp13, 0, 1);
            tlp12.Location = new Point(0, 0);
            tlp12.Margin = new Padding(0);
            tlp12.Name = "tlp12";
            tlp12.RowCount = 2;
            tlp12.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tlp12.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tlp12.Size = new Size(200, 100);
            tlp12.TabIndex = 0;
            // 
            // tlp13
            // 
            tlp13.BackColor = Color.Black;
            tlp13.ColumnCount = 2;
            tlp13.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tlp13.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tlp13.Controls.Add(label11, 1, 0);
            tlp13.Controls.Add(label12, 0, 0);
            tlp13.Location = new Point(3, 22);
            tlp13.Margin = new Padding(3, 2, 3, 2);
            tlp13.Name = "tlp13";
            tlp13.RowCount = 1;
            tlp13.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tlp13.RowStyles.Add(new RowStyle(SizeType.Absolute, 15F));
            tlp13.Size = new Size(194, 15);
            tlp13.TabIndex = 6;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Dock = DockStyle.Fill;
            label11.Font = new Font("Ink Free", 10F, FontStyle.Bold);
            label11.ForeColor = SystemColors.ButtonHighlight;
            label11.Location = new Point(100, 0);
            label11.Name = "label11";
            label11.Size = new Size(91, 15);
            label11.TabIndex = 1;
            label11.Text = "Precio1";
            label11.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Dock = DockStyle.Fill;
            label12.Font = new Font("Ink Free", 10F, FontStyle.Bold);
            label12.ForeColor = SystemColors.ButtonHighlight;
            label12.Location = new Point(3, 0);
            label12.Name = "label12";
            label12.Size = new Size(91, 15);
            label12.TabIndex = 0;
            label12.Text = "Producto1";
            label12.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // button5
            // 
            button5.BackColor = Color.Transparent;
            button5.BackgroundImageLayout = ImageLayout.None;
            button5.Dock = DockStyle.Fill;
            button5.FlatAppearance.BorderColor = Color.FromArgb(214, 34, 0);
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatStyle = FlatStyle.Popup;
            button5.Location = new Point(13, 11);
            button5.Margin = new Padding(13, 11, 13, 11);
            button5.Name = "button5";
            button5.Size = new Size(174, 150);
            button5.TabIndex = 2;
            button5.UseVisualStyleBackColor = false;
            // 
            // userControl1
            // 
            userControl1.BackColor = Color.White;
            userControl1.Location = new Point(11, 275);
            userControl1.Margin = new Padding(6, 5, 6, 5);
            userControl1.Name = "userControl1";
            userControl1.Size = new Size(474, 512);
            userControl1.TabIndex = 6;
            // 
            // userControl2
            // 
            userControl2.BackColor = Color.FromArgb(255, 152, 83);
            userControl2.Location = new Point(11, 275);
            userControl2.Margin = new Padding(3, 5, 3, 5);
            userControl2.Name = "userControl2";
            userControl2.Size = new Size(474, 512);
            userControl2.TabIndex = 7;
            // 
            // userControl3
            // 
            userControl3.BackColor = Color.FromArgb(255, 152, 83);
            userControl3.bstateCaja = true;
            userControl3.bstateTarjeta = false;
            userControl3.Location = new Point(11, 275);
            userControl3.Name = "userControl3";
            userControl3.Size = new Size(474, 512);
            userControl3.TabIndex = 8;
            userControl3.Visible = false;
            // 
            // userControl4
            // 
            userControl4.BackColor = Color.FromArgb(255, 152, 83);
            userControl4.Location = new Point(11, 275);
            userControl4.Margin = new Padding(3, 5, 3, 5);
            userControl4.Name = "userControl4";
            userControl4.Size = new Size(474, 512);
            userControl4.TabIndex = 9;
            userControl4.Visible = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(80, 34, 18);
            ClientSize = new Size(811, 861);
            Controls.Add(userControl4);
            Controls.Add(userControl3);
            Controls.Add(userControl2);
            Controls.Add(userControl1);
            Controls.Add(tlp2);
            Controls.Add(tlp1);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Hamburguesería 'Los Enlaces'";
            TopMost = true;
            FormClosed += Form1_FormClosed;
            tlp1.ResumeLayout(false);
            tlp1.PerformLayout();
            tlp2.ResumeLayout(false);
            panelDerecho1.ResumeLayout(false);
            tlp8.ResumeLayout(false);
            tlp10.ResumeLayout(false);
            tlp10.PerformLayout();
            tlp15.ResumeLayout(false);
            tlp15.PerformLayout();
            tlp9.ResumeLayout(false);
            tlp9.PerformLayout();
            tlp4.ResumeLayout(false);
            tlp4.PerformLayout();
            panelIzquierdo2.ResumeLayout(false);
            tlp5.ResumeLayout(false);
            tlpExtras.ResumeLayout(false);
            tlpExtras.PerformLayout();
            tlpProducto2.ResumeLayout(false);
            tlp7.ResumeLayout(false);
            tlp7.PerformLayout();
            tlpProducto1.ResumeLayout(false);
            tlp6.ResumeLayout(false);
            tlp6.PerformLayout();
            tlp3.ResumeLayout(false);
            tlp3.PerformLayout();
            tlp14.ResumeLayout(false);
            tlp16.ResumeLayout(false);
            tlp11.ResumeLayout(false);
            tlp11.PerformLayout();
            tlp12.ResumeLayout(false);
            tlp13.ResumeLayout(false);
            tlp13.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private VScrollBar vScrollBar1;
        private TableLayoutPanel tlp1;
        private PictureBox pb_banner;
        private Label lbl_banner;
        private TableLayoutPanel tlp2;
        private Panel panelDerecho1;
        private TableLayoutPanel tlp4;
        private TableLayoutPanel tlp3;
        private Panel panelIzquierdo2;
        private TableLayoutPanel tlp5;
        private TableLayoutPanel tlpProducto2;
        private TableLayoutPanel tlpProducto1;
        private Button btnProducto2;
        private Button btnProducto1;
        private TableLayoutPanel tlpExtras;
        private Button btnExtras;
        private Label lbl_añadirExtras;
        private TableLayoutPanel tlp7;
        private Label lbl_precioProducto2;
        private Label lbl_nombreProducto2;
        private TableLayoutPanel tlp6;
        private Label lbl_precioProducto1;
        private Label lbl_nombreProducto1;
        private TableLayoutPanel tlp8;
        private Label lbl_tipoProducto;
        private TableLayoutPanel tlp10;
        private TableLayoutPanel tlp9;
        private Label lbl_descripcionTitulo;
        private Label label2;
        private Label lbl_descripcion;
        private TableLayoutPanel tlp14;
        private Button btn_cancelar;
        private TableLayoutPanel tlp16;
        private TableLayoutPanel tlp11;
        private Label label9;
        private Label label10;
        private Button button4;
        private TableLayoutPanel tlp12;
        private TableLayoutPanel tlp13;
        private Label label11;
        private Label label12;
        private Button button5;
        public UserControl_MenuExtras usc1;
        private UserControl_MenuExtras userControl1;
        private TableLayoutPanel tlp15;
        private UserControl_QuitamosAlgo userControl2;
        public Label pro1;
        public Label pro2;
        public Label pre2;
        public Label pro3;
        public Label pre3;
        public Label pro1Extras;
        public Label pre1Extras;
        public Label pro3Extras;
        public Label pre3Extras;
        public Label pre1;
        private Label lbl_total2;
        private Label lbl_total1;
        public Button btn_añadirPagar;
        public UserControl_UltimosDetalles userControl3;
        private UserControl_MostrarFacturas userControl4;
    }
}
