﻿namespace Entrega2Eval_JavierReyes
{
    partial class UserControl_QuitamosAlgo
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserControl_QuitamosAlgo));
            pictureBanner = new PictureBox();
            tableLayoutGeneral = new TableLayoutPanel();
            pb5 = new PictureBox();
            pb4 = new PictureBox();
            pb3 = new PictureBox();
            pb2 = new PictureBox();
            b4 = new Button();
            b3 = new Button();
            b1 = new Button();
            pb1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBanner).BeginInit();
            tableLayoutGeneral.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pb5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pb4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pb3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pb2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pb1).BeginInit();
            SuspendLayout();
            // 
            // pictureBanner
            // 
            pictureBanner.BackgroundImage = (Image)resources.GetObject("pictureBanner.BackgroundImage");
            pictureBanner.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBanner.Location = new Point(0, 17);
            pictureBanner.Margin = new Padding(0);
            pictureBanner.Name = "pictureBanner";
            pictureBanner.Size = new Size(474, 133);
            pictureBanner.TabIndex = 3;
            pictureBanner.TabStop = false;
            // 
            // tableLayoutGeneral
            // 
            tableLayoutGeneral.ColumnCount = 2;
            tableLayoutGeneral.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 57F));
            tableLayoutGeneral.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 43F));
            tableLayoutGeneral.Controls.Add(pb5, 1, 4);
            tableLayoutGeneral.Controls.Add(pb4, 1, 3);
            tableLayoutGeneral.Controls.Add(pb3, 1, 2);
            tableLayoutGeneral.Controls.Add(pb2, 1, 1);
            tableLayoutGeneral.Controls.Add(b4, 0, 3);
            tableLayoutGeneral.Controls.Add(b3, 0, 2);
            tableLayoutGeneral.Controls.Add(b1, 0, 0);
            tableLayoutGeneral.Controls.Add(pb1, 1, 0);
            tableLayoutGeneral.Location = new Point(3, 167);
            tableLayoutGeneral.Name = "tableLayoutGeneral";
            tableLayoutGeneral.RowCount = 5;
            tableLayoutGeneral.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutGeneral.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutGeneral.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutGeneral.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutGeneral.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutGeneral.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutGeneral.Size = new Size(468, 342);
            tableLayoutGeneral.TabIndex = 4;
            // 
            // pb5
            // 
            pb5.BackgroundImage = (Image)resources.GetObject("pb5.BackgroundImage");
            pb5.BackgroundImageLayout = ImageLayout.Stretch;
            pb5.Dock = DockStyle.Fill;
            pb5.Location = new Point(266, 272);
            pb5.Margin = new Padding(0, 0, 70, 0);
            pb5.Name = "pb5";
            pb5.Size = new Size(132, 70);
            pb5.TabIndex = 14;
            pb5.TabStop = false;
            // 
            // pb4
            // 
            pb4.BackgroundImage = (Image)resources.GetObject("pb4.BackgroundImage");
            pb4.BackgroundImageLayout = ImageLayout.Stretch;
            pb4.Dock = DockStyle.Fill;
            pb4.Location = new Point(266, 204);
            pb4.Margin = new Padding(0, 0, 70, 0);
            pb4.Name = "pb4";
            pb4.Size = new Size(132, 68);
            pb4.TabIndex = 13;
            pb4.TabStop = false;
            // 
            // pb3
            // 
            pb3.BackgroundImage = (Image)resources.GetObject("pb3.BackgroundImage");
            pb3.BackgroundImageLayout = ImageLayout.Stretch;
            pb3.Dock = DockStyle.Fill;
            pb3.Location = new Point(266, 136);
            pb3.Margin = new Padding(0, 0, 70, 0);
            pb3.Name = "pb3";
            pb3.Size = new Size(132, 68);
            pb3.TabIndex = 12;
            pb3.TabStop = false;
            // 
            // pb2
            // 
            pb2.BackgroundImage = (Image)resources.GetObject("pb2.BackgroundImage");
            pb2.BackgroundImageLayout = ImageLayout.Stretch;
            pb2.Dock = DockStyle.Fill;
            pb2.Location = new Point(266, 68);
            pb2.Margin = new Padding(0, 0, 70, 0);
            pb2.Name = "pb2";
            pb2.Size = new Size(132, 68);
            pb2.TabIndex = 11;
            pb2.TabStop = false;
            // 
            // b4
            // 
            b4.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            b4.BackColor = Color.Red;
            b4.FlatStyle = FlatStyle.Flat;
            b4.Font = new Font("Malgun Gothic", 14F, FontStyle.Bold);
            b4.ForeColor = SystemColors.ControlLightLight;
            b4.Location = new Point(205, 207);
            b4.Margin = new Padding(3, 3, 0, 3);
            b4.Name = "b4";
            b4.Size = new Size(61, 62);
            b4.TabIndex = 7;
            b4.Text = "X";
            b4.UseVisualStyleBackColor = false;
            b4.Click += button4_Click;
            // 
            // b3
            // 
            b3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            b3.BackColor = Color.Red;
            b3.FlatStyle = FlatStyle.Flat;
            b3.Font = new Font("Malgun Gothic", 14F, FontStyle.Bold);
            b3.ForeColor = SystemColors.ControlLightLight;
            b3.Location = new Point(205, 139);
            b3.Margin = new Padding(3, 3, 0, 3);
            b3.Name = "b3";
            b3.Size = new Size(61, 62);
            b3.TabIndex = 5;
            b3.Text = "X";
            b3.UseVisualStyleBackColor = false;
            b3.Click += button3_Click;
            // 
            // b1
            // 
            b1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            b1.BackColor = Color.Red;
            b1.BackgroundImageLayout = ImageLayout.Center;
            b1.FlatStyle = FlatStyle.Flat;
            b1.Font = new Font("Malgun Gothic", 14F, FontStyle.Bold);
            b1.ForeColor = SystemColors.ControlLightLight;
            b1.Location = new Point(205, 3);
            b1.Margin = new Padding(3, 3, 0, 3);
            b1.Name = "b1";
            b1.Size = new Size(61, 62);
            b1.TabIndex = 0;
            b1.Text = "X";
            b1.UseVisualStyleBackColor = false;
            b1.Click += button1_Click;
            // 
            // pb1
            // 
            pb1.BackgroundImage = (Image)resources.GetObject("pb1.BackgroundImage");
            pb1.BackgroundImageLayout = ImageLayout.Stretch;
            pb1.Dock = DockStyle.Fill;
            pb1.Location = new Point(266, 0);
            pb1.Margin = new Padding(0, 0, 70, 0);
            pb1.Name = "pb1";
            pb1.Size = new Size(132, 68);
            pb1.TabIndex = 10;
            pb1.TabStop = false;
            // 
            // UserControl2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 152, 83);
            Controls.Add(tableLayoutGeneral);
            Controls.Add(pictureBanner);
            Margin = new Padding(3, 4, 3, 4);
            Name = "UserControl2";
            Size = new Size(474, 512);
            Click += button1_Click;
            ((System.ComponentModel.ISupportInitialize)pictureBanner).EndInit();
            tableLayoutGeneral.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pb5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pb4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pb3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pb2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pb1).EndInit();
            ResumeLayout(false);
        }

        #endregion
        public PictureBox pb4;
        public PictureBox pb3;
        public PictureBox pb2;
        public PictureBox pb1;
        public PictureBox pb5;
        public Button b4;
        public Button b3;
        public Button b1;
        public PictureBox pictureBanner;
        public TableLayoutPanel tableLayoutGeneral;
    }
}
