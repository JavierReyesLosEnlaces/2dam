﻿namespace Entrega2Eval_JavierReyes
{
    public partial class UserControl_MostrarFacturas : UserControl
    {
        public UserControl_MostrarFacturas()
        {
            InitializeComponent();
        }
    }
}
