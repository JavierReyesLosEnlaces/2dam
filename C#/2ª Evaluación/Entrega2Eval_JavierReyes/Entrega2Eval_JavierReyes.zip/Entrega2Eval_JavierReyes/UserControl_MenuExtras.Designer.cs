﻿namespace Entrega2Eval_JavierReyes
{
    partial class UserControl_MenuExtras
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            uc1_tlp1 = new TableLayoutPanel();
            panelColor6 = new Panel();
            tlpExtras6 = new TableLayoutPanel();
            buttonExtras6 = new Button();
            tableLayoutPanel6 = new TableLayoutPanel();
            labelExtras6 = new Label();
            panelColor5 = new Panel();
            tlpExtras5 = new TableLayoutPanel();
            buttonExtras5 = new Button();
            tableLayoutPanel3 = new TableLayoutPanel();
            labelExtras5 = new Label();
            panelColor4 = new Panel();
            tlpExtras4 = new TableLayoutPanel();
            buttonExtras4 = new Button();
            tableLayoutPanel5 = new TableLayoutPanel();
            labelExtras4 = new Label();
            panelColor3 = new Panel();
            tlpExtras3 = new TableLayoutPanel();
            buttonExtras3 = new Button();
            tableLayoutPanel2 = new TableLayoutPanel();
            labelExtras3 = new Label();
            panelColor2 = new Panel();
            tlpExtras2 = new TableLayoutPanel();
            buttonExtras2 = new Button();
            tableLayoutPanel4 = new TableLayoutPanel();
            labelExtras2 = new Label();
            panelColor1 = new Panel();
            tlpExtras1 = new TableLayoutPanel();
            buttonExtras1 = new Button();
            tableLayoutPanel1 = new TableLayoutPanel();
            labelExtras1 = new Label();
            precioExtras1 = new Label();
            precioExtras2 = new Label();
            tableLayoutPanel7 = new TableLayoutPanel();
            label1 = new Label();
            precioExtras3 = new Label();
            precioExtras4 = new Label();
            precioExtras5 = new Label();
            precioExtras6 = new Label();
            uc1_tlp1.SuspendLayout();
            panelColor6.SuspendLayout();
            tlpExtras6.SuspendLayout();
            tableLayoutPanel6.SuspendLayout();
            panelColor5.SuspendLayout();
            tlpExtras5.SuspendLayout();
            tableLayoutPanel3.SuspendLayout();
            panelColor4.SuspendLayout();
            tlpExtras4.SuspendLayout();
            tableLayoutPanel5.SuspendLayout();
            panelColor3.SuspendLayout();
            tlpExtras3.SuspendLayout();
            tableLayoutPanel2.SuspendLayout();
            panelColor2.SuspendLayout();
            tlpExtras2.SuspendLayout();
            tableLayoutPanel4.SuspendLayout();
            panelColor1.SuspendLayout();
            tlpExtras1.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // uc1_tlp1
            // 
            uc1_tlp1.ColumnCount = 2;
            uc1_tlp1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            uc1_tlp1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            uc1_tlp1.Controls.Add(panelColor6, 1, 2);
            uc1_tlp1.Controls.Add(panelColor5, 0, 2);
            uc1_tlp1.Controls.Add(panelColor4, 1, 1);
            uc1_tlp1.Controls.Add(panelColor3, 0, 1);
            uc1_tlp1.Controls.Add(panelColor2, 1, 0);
            uc1_tlp1.Controls.Add(panelColor1, 0, 0);
            uc1_tlp1.Dock = DockStyle.Fill;
            uc1_tlp1.Location = new Point(0, 0);
            uc1_tlp1.Name = "uc1_tlp1";
            uc1_tlp1.RowCount = 3;
            uc1_tlp1.RowStyles.Add(new RowStyle(SizeType.Percent, 33.3333321F));
            uc1_tlp1.RowStyles.Add(new RowStyle(SizeType.Percent, 33.3333321F));
            uc1_tlp1.RowStyles.Add(new RowStyle(SizeType.Percent, 33.3333321F));
            uc1_tlp1.Size = new Size(474, 512);
            uc1_tlp1.TabIndex = 0;
            // 
            // panelColor6
            // 
            panelColor6.BackColor = Color.FromArgb(255, 152, 83);
            panelColor6.Controls.Add(tlpExtras6);
            panelColor6.Dock = DockStyle.Fill;
            panelColor6.Location = new Point(237, 340);
            panelColor6.Margin = new Padding(0);
            panelColor6.Name = "panelColor6";
            panelColor6.Size = new Size(237, 172);
            panelColor6.TabIndex = 5;
            // 
            // tlpExtras6
            // 
            tlpExtras6.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tlpExtras6.ColumnCount = 1;
            tlpExtras6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlpExtras6.Controls.Add(buttonExtras6, 0, 0);
            tlpExtras6.Controls.Add(tableLayoutPanel6, 0, 1);
            tlpExtras6.Location = new Point(26, 17);
            tlpExtras6.Name = "tlpExtras6";
            tlpExtras6.RowCount = 2;
            tlpExtras6.RowStyles.Add(new RowStyle(SizeType.Percent, 80F));
            tlpExtras6.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tlpExtras6.Size = new Size(187, 140);
            tlpExtras6.TabIndex = 1;
            // 
            // buttonExtras6
            // 
            buttonExtras6.BackgroundImageLayout = ImageLayout.Stretch;
            buttonExtras6.Dock = DockStyle.Fill;
            buttonExtras6.FlatStyle = FlatStyle.Popup;
            buttonExtras6.Location = new Point(0, 0);
            buttonExtras6.Margin = new Padding(0);
            buttonExtras6.Name = "buttonExtras6";
            buttonExtras6.Size = new Size(187, 112);
            buttonExtras6.TabIndex = 2;
            buttonExtras6.UseVisualStyleBackColor = true;
            buttonExtras6.Click += buttonExtra6_Click;
            // 
            // tableLayoutPanel6
            // 
            tableLayoutPanel6.ColumnCount = 2;
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel6.Controls.Add(precioExtras6, 0, 0);
            tableLayoutPanel6.Controls.Add(labelExtras6, 0, 0);
            tableLayoutPanel6.Location = new Point(3, 115);
            tableLayoutPanel6.Name = "tableLayoutPanel6";
            tableLayoutPanel6.RowCount = 1;
            tableLayoutPanel6.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel6.Size = new Size(181, 22);
            tableLayoutPanel6.TabIndex = 3;
            // 
            // labelExtras6
            // 
            labelExtras6.AutoSize = true;
            labelExtras6.BackColor = SystemColors.ActiveCaptionText;
            labelExtras6.Dock = DockStyle.Fill;
            labelExtras6.Font = new Font("Ink Free", 10F, FontStyle.Bold);
            labelExtras6.ForeColor = SystemColors.ButtonHighlight;
            labelExtras6.Location = new Point(0, 0);
            labelExtras6.Margin = new Padding(0);
            labelExtras6.Name = "labelExtras6";
            labelExtras6.Size = new Size(90, 22);
            labelExtras6.TabIndex = 4;
            labelExtras6.Text = "labelExtras6";
            labelExtras6.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panelColor5
            // 
            panelColor5.BackColor = Color.FromArgb(255, 152, 83);
            panelColor5.Controls.Add(tlpExtras5);
            panelColor5.Dock = DockStyle.Fill;
            panelColor5.Location = new Point(0, 340);
            panelColor5.Margin = new Padding(0);
            panelColor5.Name = "panelColor5";
            panelColor5.Size = new Size(237, 172);
            panelColor5.TabIndex = 4;
            // 
            // tlpExtras5
            // 
            tlpExtras5.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tlpExtras5.ColumnCount = 1;
            tlpExtras5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlpExtras5.Controls.Add(buttonExtras5, 0, 0);
            tlpExtras5.Controls.Add(tableLayoutPanel3, 0, 1);
            tlpExtras5.Location = new Point(23, 17);
            tlpExtras5.Name = "tlpExtras5";
            tlpExtras5.RowCount = 2;
            tlpExtras5.RowStyles.Add(new RowStyle(SizeType.Percent, 80F));
            tlpExtras5.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tlpExtras5.Size = new Size(188, 140);
            tlpExtras5.TabIndex = 1;
            // 
            // buttonExtras5
            // 
            buttonExtras5.BackgroundImageLayout = ImageLayout.Stretch;
            buttonExtras5.Dock = DockStyle.Fill;
            buttonExtras5.FlatStyle = FlatStyle.Popup;
            buttonExtras5.Location = new Point(0, 0);
            buttonExtras5.Margin = new Padding(0);
            buttonExtras5.Name = "buttonExtras5";
            buttonExtras5.Size = new Size(188, 112);
            buttonExtras5.TabIndex = 2;
            buttonExtras5.UseVisualStyleBackColor = true;
            buttonExtras5.Click += buttonExtras5_Click;
            // 
            // tableLayoutPanel3
            // 
            tableLayoutPanel3.ColumnCount = 2;
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel3.Controls.Add(precioExtras5, 0, 0);
            tableLayoutPanel3.Controls.Add(labelExtras5, 0, 0);
            tableLayoutPanel3.Location = new Point(3, 115);
            tableLayoutPanel3.Name = "tableLayoutPanel3";
            tableLayoutPanel3.RowCount = 1;
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel3.Size = new Size(182, 22);
            tableLayoutPanel3.TabIndex = 3;
            // 
            // labelExtras5
            // 
            labelExtras5.AutoSize = true;
            labelExtras5.BackColor = SystemColors.ActiveCaptionText;
            labelExtras5.Dock = DockStyle.Fill;
            labelExtras5.Font = new Font("Ink Free", 10F, FontStyle.Bold);
            labelExtras5.ForeColor = SystemColors.ButtonHighlight;
            labelExtras5.Location = new Point(0, 0);
            labelExtras5.Margin = new Padding(0);
            labelExtras5.Name = "labelExtras5";
            labelExtras5.Size = new Size(91, 22);
            labelExtras5.TabIndex = 4;
            labelExtras5.Text = "labelExtras5";
            labelExtras5.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panelColor4
            // 
            panelColor4.BackColor = Color.FromArgb(255, 152, 83);
            panelColor4.Controls.Add(tlpExtras4);
            panelColor4.Dock = DockStyle.Fill;
            panelColor4.Location = new Point(237, 170);
            panelColor4.Margin = new Padding(0);
            panelColor4.Name = "panelColor4";
            panelColor4.Size = new Size(237, 170);
            panelColor4.TabIndex = 3;
            // 
            // tlpExtras4
            // 
            tlpExtras4.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tlpExtras4.ColumnCount = 1;
            tlpExtras4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlpExtras4.Controls.Add(buttonExtras4, 0, 0);
            tlpExtras4.Controls.Add(tableLayoutPanel5, 0, 1);
            tlpExtras4.Location = new Point(26, 18);
            tlpExtras4.Name = "tlpExtras4";
            tlpExtras4.RowCount = 2;
            tlpExtras4.RowStyles.Add(new RowStyle(SizeType.Percent, 80F));
            tlpExtras4.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tlpExtras4.Size = new Size(187, 135);
            tlpExtras4.TabIndex = 1;
            // 
            // buttonExtras4
            // 
            buttonExtras4.BackgroundImageLayout = ImageLayout.Stretch;
            buttonExtras4.Dock = DockStyle.Fill;
            buttonExtras4.FlatStyle = FlatStyle.Popup;
            buttonExtras4.Location = new Point(0, 0);
            buttonExtras4.Margin = new Padding(0);
            buttonExtras4.Name = "buttonExtras4";
            buttonExtras4.Size = new Size(187, 108);
            buttonExtras4.TabIndex = 2;
            buttonExtras4.UseVisualStyleBackColor = true;
            buttonExtras4.Click += buttonExtras4_Click;
            // 
            // tableLayoutPanel5
            // 
            tableLayoutPanel5.ColumnCount = 2;
            tableLayoutPanel5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel5.Controls.Add(precioExtras4, 0, 0);
            tableLayoutPanel5.Controls.Add(labelExtras4, 0, 0);
            tableLayoutPanel5.Location = new Point(3, 111);
            tableLayoutPanel5.Name = "tableLayoutPanel5";
            tableLayoutPanel5.RowCount = 1;
            tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel5.Size = new Size(181, 21);
            tableLayoutPanel5.TabIndex = 3;
            // 
            // labelExtras4
            // 
            labelExtras4.AutoSize = true;
            labelExtras4.BackColor = SystemColors.ActiveCaptionText;
            labelExtras4.Dock = DockStyle.Fill;
            labelExtras4.Font = new Font("Ink Free", 10F, FontStyle.Bold);
            labelExtras4.ForeColor = SystemColors.ButtonHighlight;
            labelExtras4.Location = new Point(0, 0);
            labelExtras4.Margin = new Padding(0);
            labelExtras4.Name = "labelExtras4";
            labelExtras4.Size = new Size(90, 21);
            labelExtras4.TabIndex = 4;
            labelExtras4.Text = "labelExtras4";
            labelExtras4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panelColor3
            // 
            panelColor3.BackColor = Color.FromArgb(255, 152, 83);
            panelColor3.Controls.Add(tlpExtras3);
            panelColor3.Dock = DockStyle.Fill;
            panelColor3.Location = new Point(0, 170);
            panelColor3.Margin = new Padding(0);
            panelColor3.Name = "panelColor3";
            panelColor3.Size = new Size(237, 170);
            panelColor3.TabIndex = 2;
            // 
            // tlpExtras3
            // 
            tlpExtras3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tlpExtras3.ColumnCount = 1;
            tlpExtras3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlpExtras3.Controls.Add(buttonExtras3, 0, 0);
            tlpExtras3.Controls.Add(tableLayoutPanel2, 0, 1);
            tlpExtras3.Location = new Point(23, 18);
            tlpExtras3.Name = "tlpExtras3";
            tlpExtras3.RowCount = 2;
            tlpExtras3.RowStyles.Add(new RowStyle(SizeType.Percent, 80F));
            tlpExtras3.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tlpExtras3.Size = new Size(188, 135);
            tlpExtras3.TabIndex = 1;
            // 
            // buttonExtras3
            // 
            buttonExtras3.BackgroundImageLayout = ImageLayout.Stretch;
            buttonExtras3.Dock = DockStyle.Fill;
            buttonExtras3.FlatStyle = FlatStyle.Popup;
            buttonExtras3.Location = new Point(0, 0);
            buttonExtras3.Margin = new Padding(0);
            buttonExtras3.Name = "buttonExtras3";
            buttonExtras3.Size = new Size(188, 108);
            buttonExtras3.TabIndex = 1;
            buttonExtras3.UseVisualStyleBackColor = true;
            buttonExtras3.Click += buttonExtras3_Click;
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 2;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.Controls.Add(precioExtras3, 0, 0);
            tableLayoutPanel2.Controls.Add(labelExtras3, 0, 0);
            tableLayoutPanel2.Location = new Point(3, 111);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 1;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.Size = new Size(182, 21);
            tableLayoutPanel2.TabIndex = 2;
            // 
            // labelExtras3
            // 
            labelExtras3.AutoSize = true;
            labelExtras3.BackColor = SystemColors.ActiveCaptionText;
            labelExtras3.Dock = DockStyle.Fill;
            labelExtras3.Font = new Font("Ink Free", 10F, FontStyle.Bold);
            labelExtras3.ForeColor = SystemColors.ButtonHighlight;
            labelExtras3.Location = new Point(0, 0);
            labelExtras3.Margin = new Padding(0);
            labelExtras3.Name = "labelExtras3";
            labelExtras3.Size = new Size(91, 21);
            labelExtras3.TabIndex = 3;
            labelExtras3.Text = "labelExtras3";
            labelExtras3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panelColor2
            // 
            panelColor2.BackColor = Color.FromArgb(255, 152, 83);
            panelColor2.Controls.Add(tlpExtras2);
            panelColor2.Dock = DockStyle.Fill;
            panelColor2.Location = new Point(237, 0);
            panelColor2.Margin = new Padding(0);
            panelColor2.Name = "panelColor2";
            panelColor2.Size = new Size(237, 170);
            panelColor2.TabIndex = 1;
            // 
            // tlpExtras2
            // 
            tlpExtras2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tlpExtras2.ColumnCount = 1;
            tlpExtras2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlpExtras2.Controls.Add(buttonExtras2, 0, 0);
            tlpExtras2.Controls.Add(tableLayoutPanel4, 0, 1);
            tlpExtras2.Location = new Point(26, 18);
            tlpExtras2.Name = "tlpExtras2";
            tlpExtras2.RowCount = 2;
            tlpExtras2.RowStyles.Add(new RowStyle(SizeType.Percent, 80F));
            tlpExtras2.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tlpExtras2.Size = new Size(187, 135);
            tlpExtras2.TabIndex = 2;
            // 
            // buttonExtras2
            // 
            buttonExtras2.BackgroundImageLayout = ImageLayout.Stretch;
            buttonExtras2.Dock = DockStyle.Fill;
            buttonExtras2.FlatStyle = FlatStyle.Popup;
            buttonExtras2.Location = new Point(0, 0);
            buttonExtras2.Margin = new Padding(0);
            buttonExtras2.Name = "buttonExtras2";
            buttonExtras2.Size = new Size(187, 108);
            buttonExtras2.TabIndex = 1;
            buttonExtras2.UseVisualStyleBackColor = true;
            buttonExtras2.Click += buttonExtras2_Click_1;
            // 
            // tableLayoutPanel4
            // 
            tableLayoutPanel4.ColumnCount = 2;
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel4.Controls.Add(precioExtras2, 0, 0);
            tableLayoutPanel4.Controls.Add(labelExtras2, 0, 0);
            tableLayoutPanel4.Location = new Point(3, 111);
            tableLayoutPanel4.Name = "tableLayoutPanel4";
            tableLayoutPanel4.RowCount = 1;
            tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel4.Size = new Size(181, 21);
            tableLayoutPanel4.TabIndex = 2;
            // 
            // labelExtras2
            // 
            labelExtras2.AutoSize = true;
            labelExtras2.BackColor = SystemColors.ActiveCaptionText;
            labelExtras2.Dock = DockStyle.Fill;
            labelExtras2.Font = new Font("Ink Free", 10F, FontStyle.Bold);
            labelExtras2.ForeColor = SystemColors.ButtonHighlight;
            labelExtras2.Location = new Point(0, 0);
            labelExtras2.Margin = new Padding(0);
            labelExtras2.Name = "labelExtras2";
            labelExtras2.Size = new Size(90, 21);
            labelExtras2.TabIndex = 3;
            labelExtras2.Text = "labelExtras2";
            labelExtras2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panelColor1
            // 
            panelColor1.BackColor = Color.FromArgb(255, 152, 83);
            panelColor1.Controls.Add(tlpExtras1);
            panelColor1.Dock = DockStyle.Fill;
            panelColor1.Location = new Point(0, 0);
            panelColor1.Margin = new Padding(0);
            panelColor1.Name = "panelColor1";
            panelColor1.Size = new Size(237, 170);
            panelColor1.TabIndex = 0;
            // 
            // tlpExtras1
            // 
            tlpExtras1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tlpExtras1.ColumnCount = 1;
            tlpExtras1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlpExtras1.Controls.Add(buttonExtras1, 0, 0);
            tlpExtras1.Controls.Add(tableLayoutPanel1, 0, 1);
            tlpExtras1.Location = new Point(23, 18);
            tlpExtras1.Name = "tlpExtras1";
            tlpExtras1.RowCount = 2;
            tlpExtras1.RowStyles.Add(new RowStyle(SizeType.Percent, 80F));
            tlpExtras1.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tlpExtras1.Size = new Size(188, 135);
            tlpExtras1.TabIndex = 2;
            // 
            // buttonExtras1
            // 
            buttonExtras1.BackgroundImageLayout = ImageLayout.Stretch;
            buttonExtras1.Dock = DockStyle.Fill;
            buttonExtras1.FlatStyle = FlatStyle.Popup;
            buttonExtras1.Location = new Point(0, 0);
            buttonExtras1.Margin = new Padding(0);
            buttonExtras1.Name = "buttonExtras1";
            buttonExtras1.Size = new Size(188, 108);
            buttonExtras1.TabIndex = 1;
            buttonExtras1.UseVisualStyleBackColor = true;
            buttonExtras1.Click += buttonExtras1_Click_1;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Controls.Add(precioExtras1, 0, 0);
            tableLayoutPanel1.Controls.Add(labelExtras1, 0, 0);
            tableLayoutPanel1.Location = new Point(3, 111);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Size = new Size(182, 21);
            tableLayoutPanel1.TabIndex = 2;
            // 
            // labelExtras1
            // 
            labelExtras1.AutoSize = true;
            labelExtras1.BackColor = SystemColors.ActiveCaptionText;
            labelExtras1.Dock = DockStyle.Fill;
            labelExtras1.Font = new Font("Ink Free", 10F, FontStyle.Bold);
            labelExtras1.ForeColor = SystemColors.ButtonHighlight;
            labelExtras1.Location = new Point(0, 0);
            labelExtras1.Margin = new Padding(0);
            labelExtras1.Name = "labelExtras1";
            labelExtras1.Size = new Size(91, 21);
            labelExtras1.TabIndex = 3;
            labelExtras1.Text = "labelExtras1";
            labelExtras1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // precioExtras1
            // 
            precioExtras1.AutoSize = true;
            precioExtras1.BackColor = SystemColors.ActiveCaptionText;
            precioExtras1.Dock = DockStyle.Fill;
            precioExtras1.Font = new Font("Ink Free", 10F, FontStyle.Bold);
            precioExtras1.ForeColor = SystemColors.ButtonHighlight;
            precioExtras1.Location = new Point(91, 0);
            precioExtras1.Margin = new Padding(0);
            precioExtras1.Name = "precioExtras1";
            precioExtras1.Size = new Size(91, 21);
            precioExtras1.TabIndex = 4;
            precioExtras1.Text = "precioExtras1";
            precioExtras1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // precioExtras2
            // 
            precioExtras2.AutoSize = true;
            precioExtras2.BackColor = SystemColors.ActiveCaptionText;
            precioExtras2.Dock = DockStyle.Fill;
            precioExtras2.Font = new Font("Ink Free", 10F, FontStyle.Bold);
            precioExtras2.ForeColor = SystemColors.ButtonHighlight;
            precioExtras2.Location = new Point(90, 0);
            precioExtras2.Margin = new Padding(0);
            precioExtras2.Name = "precioExtras2";
            precioExtras2.Size = new Size(91, 21);
            precioExtras2.TabIndex = 4;
            precioExtras2.Text = "precioExtras2";
            precioExtras2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel7
            // 
            tableLayoutPanel7.ColumnCount = 2;
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel7.Location = new Point(0, 0);
            tableLayoutPanel7.Name = "tableLayoutPanel7";
            tableLayoutPanel7.RowCount = 1;
            tableLayoutPanel7.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel7.Size = new Size(200, 100);
            tableLayoutPanel7.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ActiveCaptionText;
            label1.Dock = DockStyle.Fill;
            label1.Font = new Font("Ink Free", 10F, FontStyle.Bold);
            label1.ForeColor = SystemColors.ButtonHighlight;
            label1.Location = new Point(0, 0);
            label1.Margin = new Padding(0);
            label1.Name = "label1";
            label1.Size = new Size(100, 100);
            label1.TabIndex = 3;
            label1.Text = "label1";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // precioExtras3
            // 
            precioExtras3.AutoSize = true;
            precioExtras3.BackColor = SystemColors.ActiveCaptionText;
            precioExtras3.Dock = DockStyle.Fill;
            precioExtras3.Font = new Font("Ink Free", 10F, FontStyle.Bold);
            precioExtras3.ForeColor = SystemColors.ButtonHighlight;
            precioExtras3.Location = new Point(91, 0);
            precioExtras3.Margin = new Padding(0);
            precioExtras3.Name = "precioExtras3";
            precioExtras3.Size = new Size(91, 21);
            precioExtras3.TabIndex = 5;
            precioExtras3.Text = "precioExtras3";
            precioExtras3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // precioExtras4
            // 
            precioExtras4.AutoSize = true;
            precioExtras4.BackColor = SystemColors.ActiveCaptionText;
            precioExtras4.Dock = DockStyle.Fill;
            precioExtras4.Font = new Font("Ink Free", 10F, FontStyle.Bold);
            precioExtras4.ForeColor = SystemColors.ButtonHighlight;
            precioExtras4.Location = new Point(90, 0);
            precioExtras4.Margin = new Padding(0);
            precioExtras4.Name = "precioExtras4";
            precioExtras4.Size = new Size(91, 21);
            precioExtras4.TabIndex = 5;
            precioExtras4.Text = "precioExtras4";
            precioExtras4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // precioExtras5
            // 
            precioExtras5.AutoSize = true;
            precioExtras5.BackColor = SystemColors.ActiveCaptionText;
            precioExtras5.Dock = DockStyle.Fill;
            precioExtras5.Font = new Font("Ink Free", 10F, FontStyle.Bold);
            precioExtras5.ForeColor = SystemColors.ButtonHighlight;
            precioExtras5.Location = new Point(91, 0);
            precioExtras5.Margin = new Padding(0);
            precioExtras5.Name = "precioExtras5";
            precioExtras5.Size = new Size(91, 22);
            precioExtras5.TabIndex = 5;
            precioExtras5.Text = "precioExtras5";
            precioExtras5.TextAlign = ContentAlignment.TopCenter;
            // 
            // precioExtras6
            // 
            precioExtras6.AutoSize = true;
            precioExtras6.BackColor = SystemColors.ActiveCaptionText;
            precioExtras6.Dock = DockStyle.Fill;
            precioExtras6.Font = new Font("Ink Free", 10F, FontStyle.Bold);
            precioExtras6.ForeColor = SystemColors.ButtonHighlight;
            precioExtras6.Location = new Point(90, 0);
            precioExtras6.Margin = new Padding(0);
            precioExtras6.Name = "precioExtras6";
            precioExtras6.Size = new Size(91, 22);
            precioExtras6.TabIndex = 5;
            precioExtras6.Text = "precioExtras6";
            precioExtras6.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // UserControl1
            // 
            BackColor = Color.White;
            Controls.Add(uc1_tlp1);
            Name = "UserControl1";
            Size = new Size(474, 512);
            uc1_tlp1.ResumeLayout(false);
            panelColor6.ResumeLayout(false);
            tlpExtras6.ResumeLayout(false);
            tableLayoutPanel6.ResumeLayout(false);
            tableLayoutPanel6.PerformLayout();
            panelColor5.ResumeLayout(false);
            tlpExtras5.ResumeLayout(false);
            tableLayoutPanel3.ResumeLayout(false);
            tableLayoutPanel3.PerformLayout();
            panelColor4.ResumeLayout(false);
            tlpExtras4.ResumeLayout(false);
            tableLayoutPanel5.ResumeLayout(false);
            tableLayoutPanel5.PerformLayout();
            panelColor3.ResumeLayout(false);
            tlpExtras3.ResumeLayout(false);
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel2.PerformLayout();
            panelColor2.ResumeLayout(false);
            tlpExtras2.ResumeLayout(false);
            tableLayoutPanel4.ResumeLayout(false);
            tableLayoutPanel4.PerformLayout();
            panelColor1.ResumeLayout(false);
            tlpExtras1.ResumeLayout(false);
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        public Button buttonExtras6;
        public Button buttonExtras5;
        public Button buttonExtras3;
        public Button buttonExtras4;
        public Button buttonExtras1;
        public Button buttonExtras2;
        public Panel panelColor6;
        public Panel panelColor5;
        public Panel panelColor4;
        public Panel panelColor3;
        public Panel panelColor2;
        public Panel panelColor1;
        public TableLayoutPanel tlpExtras1;
        public TableLayoutPanel tlpExtras2;
        public TableLayoutPanel uc1_tlp1;
        public TableLayoutPanel tlpExtras6;
        public TableLayoutPanel tlpExtras5;
        public TableLayoutPanel tlpExtras4;
        public TableLayoutPanel tlpExtras3;
        private Label labelExtra2;
        private TableLayoutPanel tableLayoutPanel1;
        private TableLayoutPanel tableLayoutPanel6;
        public Label labelExtras6;
        private TableLayoutPanel tableLayoutPanel3;
        public Label labelExtras5;
        private TableLayoutPanel tableLayoutPanel5;
        public Label labelExtras4;
        private TableLayoutPanel tableLayoutPanel2;
        public Label labelExtras3;
        private TableLayoutPanel tableLayoutPanel4;
        public Label labelExtras2;
        public Label labelExtras1;
        public Label precioExtras5;
        public Label precioExtras4;
        public Label precioExtras3;
        public Label precioExtras2;
        public Label precioExtras1;
        private TableLayoutPanel tableLayoutPanel7;
        public Label label1;
        public Label precioExtras6;
    }
}
