﻿namespace TallerDeCoches_ProyectoFinal_ReyesÁlvarez
{
    partial class Form_Empleado
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Empleado));
            tlp1 = new TableLayoutPanel();
            tlp2 = new TableLayoutPanel();
            menuRegistrarEmpleado = new TableLayoutPanel();
            tlp10 = new TableLayoutPanel();
            tlp12 = new TableLayoutPanel();
            lb_registro_nombre = new Label();
            lb_registro_primerApellido = new Label();
            lb_registro_segundoApellido = new Label();
            lb_registro_dniNie = new Label();
            lb_registro_telefono = new Label();
            lb_registro_correo = new Label();
            textbox_re_nombre = new TextBox();
            textbox_re_primerApellido = new TextBox();
            textbox_re_segundoApellido = new TextBox();
            textbox_re_dni = new TextBox();
            textbox_re_telefono = new TextBox();
            textbox_re_correo = new TextBox();
            tlp7 = new TableLayoutPanel();
            textbox_re_salarioBase = new TextBox();
            textbox_re_salarioExtra = new TextBox();
            textbox_re_fechaInicioContrato = new TextBox();
            textbox_re_nombreUsuario = new TextBox();
            textbox_re_contraseñaUsuario = new TextBox();
            btn_registrarEmpleado_crearEmpleado = new Button();
            lb_registro_salarioBaseç = new Label();
            lb_registro_salarioExtra = new Label();
            lb_registro_fechaInicioContracto = new Label();
            lb_registro_nombreUsuario = new Label();
            lb_registro_contraseña = new Label();
            label8 = new Label();
            tlp3 = new TableLayoutPanel();
            btn_baseDeDatos = new Button();
            btn_gestionarPedidos = new Button();
            btn_registrarEmpleado = new Button();
            btn_salirAlLogin = new Button();
            btn_salir = new Button();
            tlp4 = new TableLayoutPanel();
            tlp5 = new TableLayoutPanel();
            pictureBox1 = new PictureBox();
            label_nombreUsuario = new Label();
            labelHora = new Label();
            tlp6 = new TableLayoutPanel();
            timer1 = new System.Windows.Forms.Timer(components);
            tlp8 = new TableLayoutPanel();
            tlp9 = new TableLayoutPanel();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            textBox6 = new TextBox();
            tlp11 = new TableLayoutPanel();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            textBox7 = new TextBox();
            textBox8 = new TextBox();
            textBox9 = new TextBox();
            textBox10 = new TextBox();
            textBox11 = new TextBox();
            textBox12 = new TextBox();
            menuBaseDeDatos = new TabControl();
            tabPageEmpleados = new TabPage();
            ucPanel_tipoa_empleados = new UCPanel_tipoA();
            tabPageClientes = new TabPage();
            ucPanel_tipoa_clientes = new UCPanel_tipoA();
            tabPageUsuarios = new TabPage();
            ucPanel_tipoa_usuarios = new UCPanel_tipoA();
            tabPagePedidos = new TabPage();
            ucPanel_tipoa_pedidos = new UCPanel_tipoA();
            tabPageCoches = new TabPage();
            ucPanel_tipoa_coches = new UCPanel_tipoA();
            tabPageServicios = new TabPage();
            ucPanel_tipoa_servicios = new UCPanel_tipoA();
            tabPageTalleres = new TabPage();
            ucPanel_tipoa_talleres = new UCPanel_tipoA();
            tabPageRoles = new TabPage();
            ucPanel_tipoa_roles = new UCPanel_tipoA();
            menuGestionarPedidos = new TableLayoutPanel();
            dataGridView_pedidosPendientes = new DataGridView();
            tableLayoutPanel1 = new TableLayoutPanel();
            btn_aceptarPedidoPendiente = new Button();
            btn_rechazarPedidoPendiente = new Button();
            label9 = new Label();
            button1 = new Button();
            panelBienvenida = new Panel();
            tableLayoutPanel2 = new TableLayoutPanel();
            btn_info = new Button();
            label_bienvenida = new Label();
            toolTip1 = new ToolTip(components);
            tlp1.SuspendLayout();
            tlp2.SuspendLayout();
            menuRegistrarEmpleado.SuspendLayout();
            tlp10.SuspendLayout();
            tlp12.SuspendLayout();
            tlp7.SuspendLayout();
            tlp3.SuspendLayout();
            tlp4.SuspendLayout();
            tlp5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            tlp9.SuspendLayout();
            tlp11.SuspendLayout();
            menuBaseDeDatos.SuspendLayout();
            tabPageEmpleados.SuspendLayout();
            tabPageClientes.SuspendLayout();
            tabPageUsuarios.SuspendLayout();
            tabPagePedidos.SuspendLayout();
            tabPageCoches.SuspendLayout();
            tabPageServicios.SuspendLayout();
            tabPageTalleres.SuspendLayout();
            tabPageRoles.SuspendLayout();
            menuGestionarPedidos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView_pedidosPendientes).BeginInit();
            tableLayoutPanel1.SuspendLayout();
            panelBienvenida.SuspendLayout();
            tableLayoutPanel2.SuspendLayout();
            SuspendLayout();
            // 
            // tlp1
            // 
            tlp1.AllowDrop = true;
            tlp1.ColumnCount = 1;
            tlp1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlp1.Controls.Add(tlp2, 0, 2);
            tlp1.Controls.Add(btn_salir, 0, 0);
            tlp1.Controls.Add(tlp4, 0, 1);
            tlp1.Dock = DockStyle.Fill;
            tlp1.Location = new Point(5, 5);
            tlp1.Margin = new Padding(0);
            tlp1.Name = "tlp1";
            tlp1.RowCount = 3;
            tlp1.RowStyles.Add(new RowStyle(SizeType.Percent, 4F));
            tlp1.RowStyles.Add(new RowStyle(SizeType.Percent, 4F));
            tlp1.RowStyles.Add(new RowStyle(SizeType.Percent, 92F));
            tlp1.Size = new Size(1148, 1161);
            tlp1.TabIndex = 0;
            // 
            // tlp2
            // 
            tlp2.BackColor = SystemColors.Control;
            tlp2.ColumnCount = 2;
            tlp2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12.2807F));
            tlp2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 87.7193F));
            tlp2.Controls.Add(menuRegistrarEmpleado, 0, 0);
            tlp2.Controls.Add(tlp3, 0, 0);
            tlp2.Dock = DockStyle.Fill;
            tlp2.Location = new Point(0, 92);
            tlp2.Margin = new Padding(0);
            tlp2.Name = "tlp2";
            tlp2.RowCount = 1;
            tlp2.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tlp2.Size = new Size(1148, 1069);
            tlp2.TabIndex = 2;
            // 
            // menuRegistrarEmpleado
            // 
            menuRegistrarEmpleado.ColumnCount = 1;
            menuRegistrarEmpleado.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            menuRegistrarEmpleado.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            menuRegistrarEmpleado.Controls.Add(tlp10, 0, 1);
            menuRegistrarEmpleado.Controls.Add(label8, 0, 0);
            menuRegistrarEmpleado.Dock = DockStyle.Fill;
            menuRegistrarEmpleado.Location = new Point(140, 0);
            menuRegistrarEmpleado.Margin = new Padding(0);
            menuRegistrarEmpleado.Name = "menuRegistrarEmpleado";
            menuRegistrarEmpleado.RowCount = 2;
            menuRegistrarEmpleado.RowStyles.Add(new RowStyle(SizeType.Percent, 10F));
            menuRegistrarEmpleado.RowStyles.Add(new RowStyle(SizeType.Percent, 90F));
            menuRegistrarEmpleado.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            menuRegistrarEmpleado.Size = new Size(1008, 1069);
            menuRegistrarEmpleado.TabIndex = 2;
            // 
            // tlp10
            // 
            tlp10.BackColor = Color.White;
            tlp10.ColumnCount = 2;
            tlp10.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tlp10.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tlp10.Controls.Add(tlp12, 0, 0);
            tlp10.Controls.Add(tlp7, 1, 0);
            tlp10.Dock = DockStyle.Fill;
            tlp10.Location = new Point(0, 106);
            tlp10.Margin = new Padding(0);
            tlp10.Name = "tlp10";
            tlp10.RowCount = 1;
            tlp10.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tlp10.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tlp10.Size = new Size(1008, 963);
            tlp10.TabIndex = 0;
            // 
            // tlp12
            // 
            tlp12.BackColor = SystemColors.Control;
            tlp12.ColumnCount = 1;
            tlp12.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlp12.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tlp12.Controls.Add(lb_registro_nombre, 0, 0);
            tlp12.Controls.Add(lb_registro_primerApellido, 0, 2);
            tlp12.Controls.Add(lb_registro_segundoApellido, 0, 4);
            tlp12.Controls.Add(lb_registro_dniNie, 0, 6);
            tlp12.Controls.Add(lb_registro_telefono, 0, 8);
            tlp12.Controls.Add(lb_registro_correo, 0, 10);
            tlp12.Controls.Add(textbox_re_nombre, 0, 1);
            tlp12.Controls.Add(textbox_re_primerApellido, 0, 3);
            tlp12.Controls.Add(textbox_re_segundoApellido, 0, 5);
            tlp12.Controls.Add(textbox_re_dni, 0, 7);
            tlp12.Controls.Add(textbox_re_telefono, 0, 9);
            tlp12.Controls.Add(textbox_re_correo, 0, 11);
            tlp12.Dock = DockStyle.Fill;
            tlp12.Location = new Point(200, 50);
            tlp12.Margin = new Padding(200, 50, 0, 50);
            tlp12.Name = "tlp12";
            tlp12.RowCount = 12;
            tlp12.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333332F));
            tlp12.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333332F));
            tlp12.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333332F));
            tlp12.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333332F));
            tlp12.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333332F));
            tlp12.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333332F));
            tlp12.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333332F));
            tlp12.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333332F));
            tlp12.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333332F));
            tlp12.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333332F));
            tlp12.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333332F));
            tlp12.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333332F));
            tlp12.Size = new Size(304, 863);
            tlp12.TabIndex = 0;
            // 
            // lb_registro_nombre
            // 
            lb_registro_nombre.AutoSize = true;
            lb_registro_nombre.Dock = DockStyle.Fill;
            lb_registro_nombre.Font = new Font("Cooper Black", 12F);
            lb_registro_nombre.ForeColor = Color.FromArgb(39, 50, 56);
            lb_registro_nombre.Location = new Point(3, 0);
            lb_registro_nombre.Name = "lb_registro_nombre";
            lb_registro_nombre.Size = new Size(298, 71);
            lb_registro_nombre.TabIndex = 0;
            lb_registro_nombre.Text = "Nombre";
            lb_registro_nombre.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lb_registro_primerApellido
            // 
            lb_registro_primerApellido.AutoSize = true;
            lb_registro_primerApellido.Dock = DockStyle.Fill;
            lb_registro_primerApellido.Font = new Font("Cooper Black", 12F);
            lb_registro_primerApellido.ForeColor = Color.FromArgb(39, 50, 56);
            lb_registro_primerApellido.Location = new Point(3, 142);
            lb_registro_primerApellido.Name = "lb_registro_primerApellido";
            lb_registro_primerApellido.Size = new Size(298, 71);
            lb_registro_primerApellido.TabIndex = 1;
            lb_registro_primerApellido.Text = "Primer apellido";
            lb_registro_primerApellido.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lb_registro_segundoApellido
            // 
            lb_registro_segundoApellido.AutoSize = true;
            lb_registro_segundoApellido.Dock = DockStyle.Fill;
            lb_registro_segundoApellido.Font = new Font("Cooper Black", 12F);
            lb_registro_segundoApellido.ForeColor = Color.FromArgb(39, 50, 56);
            lb_registro_segundoApellido.Location = new Point(3, 284);
            lb_registro_segundoApellido.Name = "lb_registro_segundoApellido";
            lb_registro_segundoApellido.Size = new Size(298, 71);
            lb_registro_segundoApellido.TabIndex = 2;
            lb_registro_segundoApellido.Text = "Segundo apellido";
            lb_registro_segundoApellido.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lb_registro_dniNie
            // 
            lb_registro_dniNie.AutoSize = true;
            lb_registro_dniNie.Dock = DockStyle.Fill;
            lb_registro_dniNie.Font = new Font("Cooper Black", 12F);
            lb_registro_dniNie.ForeColor = Color.FromArgb(39, 50, 56);
            lb_registro_dniNie.Location = new Point(3, 426);
            lb_registro_dniNie.Name = "lb_registro_dniNie";
            lb_registro_dniNie.Size = new Size(298, 71);
            lb_registro_dniNie.TabIndex = 3;
            lb_registro_dniNie.Text = "DNI / NIE";
            lb_registro_dniNie.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lb_registro_telefono
            // 
            lb_registro_telefono.AutoSize = true;
            lb_registro_telefono.Dock = DockStyle.Fill;
            lb_registro_telefono.Font = new Font("Cooper Black", 12F);
            lb_registro_telefono.ForeColor = Color.FromArgb(39, 50, 56);
            lb_registro_telefono.Location = new Point(3, 568);
            lb_registro_telefono.Name = "lb_registro_telefono";
            lb_registro_telefono.Size = new Size(298, 71);
            lb_registro_telefono.TabIndex = 4;
            lb_registro_telefono.Text = "Teléfono";
            lb_registro_telefono.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lb_registro_correo
            // 
            lb_registro_correo.AutoSize = true;
            lb_registro_correo.Dock = DockStyle.Fill;
            lb_registro_correo.Font = new Font("Cooper Black", 12F);
            lb_registro_correo.ForeColor = Color.FromArgb(39, 50, 56);
            lb_registro_correo.Location = new Point(3, 710);
            lb_registro_correo.Name = "lb_registro_correo";
            lb_registro_correo.Size = new Size(298, 71);
            lb_registro_correo.TabIndex = 5;
            lb_registro_correo.Text = "Correo electrónico";
            lb_registro_correo.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // textbox_re_nombre
            // 
            textbox_re_nombre.Dock = DockStyle.Fill;
            textbox_re_nombre.Location = new Point(30, 71);
            textbox_re_nombre.Margin = new Padding(30, 0, 30, 0);
            textbox_re_nombre.Name = "textbox_re_nombre";
            textbox_re_nombre.Size = new Size(244, 27);
            textbox_re_nombre.TabIndex = 6;
            // 
            // textbox_re_primerApellido
            // 
            textbox_re_primerApellido.Dock = DockStyle.Fill;
            textbox_re_primerApellido.Location = new Point(30, 213);
            textbox_re_primerApellido.Margin = new Padding(30, 0, 30, 0);
            textbox_re_primerApellido.Name = "textbox_re_primerApellido";
            textbox_re_primerApellido.Size = new Size(244, 27);
            textbox_re_primerApellido.TabIndex = 7;
            // 
            // textbox_re_segundoApellido
            // 
            textbox_re_segundoApellido.Dock = DockStyle.Fill;
            textbox_re_segundoApellido.Location = new Point(30, 355);
            textbox_re_segundoApellido.Margin = new Padding(30, 0, 30, 0);
            textbox_re_segundoApellido.Name = "textbox_re_segundoApellido";
            textbox_re_segundoApellido.Size = new Size(244, 27);
            textbox_re_segundoApellido.TabIndex = 8;
            // 
            // textbox_re_dni
            // 
            textbox_re_dni.Dock = DockStyle.Fill;
            textbox_re_dni.Location = new Point(30, 497);
            textbox_re_dni.Margin = new Padding(30, 0, 30, 0);
            textbox_re_dni.Name = "textbox_re_dni";
            textbox_re_dni.Size = new Size(244, 27);
            textbox_re_dni.TabIndex = 9;
            // 
            // textbox_re_telefono
            // 
            textbox_re_telefono.Dock = DockStyle.Fill;
            textbox_re_telefono.Location = new Point(30, 639);
            textbox_re_telefono.Margin = new Padding(30, 0, 30, 0);
            textbox_re_telefono.Name = "textbox_re_telefono";
            textbox_re_telefono.Size = new Size(244, 27);
            textbox_re_telefono.TabIndex = 10;
            // 
            // textbox_re_correo
            // 
            textbox_re_correo.Dock = DockStyle.Fill;
            textbox_re_correo.Location = new Point(30, 781);
            textbox_re_correo.Margin = new Padding(30, 0, 30, 0);
            textbox_re_correo.Name = "textbox_re_correo";
            textbox_re_correo.Size = new Size(244, 27);
            textbox_re_correo.TabIndex = 11;
            // 
            // tlp7
            // 
            tlp7.BackColor = SystemColors.Control;
            tlp7.ColumnCount = 1;
            tlp7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlp7.Controls.Add(textbox_re_salarioBase, 0, 1);
            tlp7.Controls.Add(textbox_re_salarioExtra, 0, 3);
            tlp7.Controls.Add(textbox_re_fechaInicioContrato, 0, 5);
            tlp7.Controls.Add(textbox_re_nombreUsuario, 0, 7);
            tlp7.Controls.Add(textbox_re_contraseñaUsuario, 0, 9);
            tlp7.Controls.Add(btn_registrarEmpleado_crearEmpleado, 0, 10);
            tlp7.Controls.Add(lb_registro_salarioBaseç, 0, 0);
            tlp7.Controls.Add(lb_registro_salarioExtra, 0, 2);
            tlp7.Controls.Add(lb_registro_fechaInicioContracto, 0, 4);
            tlp7.Controls.Add(lb_registro_nombreUsuario, 0, 6);
            tlp7.Controls.Add(lb_registro_contraseña, 0, 8);
            tlp7.Dock = DockStyle.Fill;
            tlp7.Location = new Point(504, 50);
            tlp7.Margin = new Padding(0, 50, 200, 50);
            tlp7.Name = "tlp7";
            tlp7.RowCount = 11;
            tlp7.RowStyles.Add(new RowStyle(SizeType.Percent, 9.09091F));
            tlp7.RowStyles.Add(new RowStyle(SizeType.Percent, 9.09091F));
            tlp7.RowStyles.Add(new RowStyle(SizeType.Percent, 9.09091F));
            tlp7.RowStyles.Add(new RowStyle(SizeType.Percent, 9.09091F));
            tlp7.RowStyles.Add(new RowStyle(SizeType.Percent, 9.09091F));
            tlp7.RowStyles.Add(new RowStyle(SizeType.Percent, 9.09091F));
            tlp7.RowStyles.Add(new RowStyle(SizeType.Percent, 9.09091F));
            tlp7.RowStyles.Add(new RowStyle(SizeType.Percent, 9.09091F));
            tlp7.RowStyles.Add(new RowStyle(SizeType.Percent, 9.09091F));
            tlp7.RowStyles.Add(new RowStyle(SizeType.Percent, 9.09091F));
            tlp7.RowStyles.Add(new RowStyle(SizeType.Percent, 9.09091F));
            tlp7.Size = new Size(304, 863);
            tlp7.TabIndex = 1;
            // 
            // textbox_re_salarioBase
            // 
            textbox_re_salarioBase.Dock = DockStyle.Fill;
            textbox_re_salarioBase.Location = new Point(30, 78);
            textbox_re_salarioBase.Margin = new Padding(30, 0, 30, 0);
            textbox_re_salarioBase.Name = "textbox_re_salarioBase";
            textbox_re_salarioBase.Size = new Size(244, 27);
            textbox_re_salarioBase.TabIndex = 0;
            // 
            // textbox_re_salarioExtra
            // 
            textbox_re_salarioExtra.Dock = DockStyle.Fill;
            textbox_re_salarioExtra.Location = new Point(30, 234);
            textbox_re_salarioExtra.Margin = new Padding(30, 0, 30, 0);
            textbox_re_salarioExtra.Name = "textbox_re_salarioExtra";
            textbox_re_salarioExtra.Size = new Size(244, 27);
            textbox_re_salarioExtra.TabIndex = 1;
            // 
            // textbox_re_fechaInicioContrato
            // 
            textbox_re_fechaInicioContrato.Dock = DockStyle.Fill;
            textbox_re_fechaInicioContrato.Location = new Point(30, 390);
            textbox_re_fechaInicioContrato.Margin = new Padding(30, 0, 30, 0);
            textbox_re_fechaInicioContrato.Name = "textbox_re_fechaInicioContrato";
            textbox_re_fechaInicioContrato.Size = new Size(244, 27);
            textbox_re_fechaInicioContrato.TabIndex = 2;
            // 
            // textbox_re_nombreUsuario
            // 
            textbox_re_nombreUsuario.Dock = DockStyle.Fill;
            textbox_re_nombreUsuario.Location = new Point(30, 546);
            textbox_re_nombreUsuario.Margin = new Padding(30, 0, 30, 0);
            textbox_re_nombreUsuario.Name = "textbox_re_nombreUsuario";
            textbox_re_nombreUsuario.Size = new Size(244, 27);
            textbox_re_nombreUsuario.TabIndex = 3;
            // 
            // textbox_re_contraseñaUsuario
            // 
            textbox_re_contraseñaUsuario.Dock = DockStyle.Fill;
            textbox_re_contraseñaUsuario.Location = new Point(30, 702);
            textbox_re_contraseñaUsuario.Margin = new Padding(30, 0, 30, 0);
            textbox_re_contraseñaUsuario.Name = "textbox_re_contraseñaUsuario";
            textbox_re_contraseñaUsuario.Size = new Size(244, 27);
            textbox_re_contraseñaUsuario.TabIndex = 4;
            // 
            // btn_registrarEmpleado_crearEmpleado
            // 
            btn_registrarEmpleado_crearEmpleado.BackColor = Color.FromArgb(117, 230, 164);
            btn_registrarEmpleado_crearEmpleado.Dock = DockStyle.Fill;
            btn_registrarEmpleado_crearEmpleado.FlatAppearance.BorderColor = Color.FromArgb(39, 50, 56);
            btn_registrarEmpleado_crearEmpleado.FlatStyle = FlatStyle.Flat;
            btn_registrarEmpleado_crearEmpleado.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btn_registrarEmpleado_crearEmpleado.ForeColor = Color.FromArgb(39, 50, 56);
            btn_registrarEmpleado_crearEmpleado.Location = new Point(30, 780);
            btn_registrarEmpleado_crearEmpleado.Margin = new Padding(30, 0, 30, 30);
            btn_registrarEmpleado_crearEmpleado.Name = "btn_registrarEmpleado_crearEmpleado";
            btn_registrarEmpleado_crearEmpleado.Size = new Size(244, 53);
            btn_registrarEmpleado_crearEmpleado.TabIndex = 5;
            btn_registrarEmpleado_crearEmpleado.Text = "CREAR EMPLEADO";
            btn_registrarEmpleado_crearEmpleado.UseVisualStyleBackColor = false;
            btn_registrarEmpleado_crearEmpleado.Click += btn_registrarEmpleado_Click;
            // 
            // lb_registro_salarioBaseç
            // 
            lb_registro_salarioBaseç.AutoSize = true;
            lb_registro_salarioBaseç.Dock = DockStyle.Fill;
            lb_registro_salarioBaseç.Font = new Font("Cooper Black", 12F);
            lb_registro_salarioBaseç.ForeColor = Color.FromArgb(39, 50, 56);
            lb_registro_salarioBaseç.Location = new Point(3, 0);
            lb_registro_salarioBaseç.Name = "lb_registro_salarioBaseç";
            lb_registro_salarioBaseç.Size = new Size(298, 78);
            lb_registro_salarioBaseç.TabIndex = 6;
            lb_registro_salarioBaseç.Text = "Salario base";
            lb_registro_salarioBaseç.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lb_registro_salarioExtra
            // 
            lb_registro_salarioExtra.AutoSize = true;
            lb_registro_salarioExtra.Dock = DockStyle.Fill;
            lb_registro_salarioExtra.Font = new Font("Cooper Black", 12F);
            lb_registro_salarioExtra.ForeColor = Color.FromArgb(39, 50, 56);
            lb_registro_salarioExtra.Location = new Point(3, 156);
            lb_registro_salarioExtra.Name = "lb_registro_salarioExtra";
            lb_registro_salarioExtra.Size = new Size(298, 78);
            lb_registro_salarioExtra.TabIndex = 7;
            lb_registro_salarioExtra.Text = "Salario extra";
            lb_registro_salarioExtra.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lb_registro_fechaInicioContracto
            // 
            lb_registro_fechaInicioContracto.AutoSize = true;
            lb_registro_fechaInicioContracto.Dock = DockStyle.Fill;
            lb_registro_fechaInicioContracto.Font = new Font("Cooper Black", 12F);
            lb_registro_fechaInicioContracto.ForeColor = Color.FromArgb(39, 50, 56);
            lb_registro_fechaInicioContracto.Location = new Point(3, 312);
            lb_registro_fechaInicioContracto.Name = "lb_registro_fechaInicioContracto";
            lb_registro_fechaInicioContracto.Size = new Size(298, 78);
            lb_registro_fechaInicioContracto.TabIndex = 8;
            lb_registro_fechaInicioContracto.Text = "Fecha de inicio de contrato";
            lb_registro_fechaInicioContracto.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lb_registro_nombreUsuario
            // 
            lb_registro_nombreUsuario.AutoSize = true;
            lb_registro_nombreUsuario.Dock = DockStyle.Fill;
            lb_registro_nombreUsuario.Font = new Font("Cooper Black", 12F);
            lb_registro_nombreUsuario.ForeColor = Color.FromArgb(39, 50, 56);
            lb_registro_nombreUsuario.Location = new Point(3, 468);
            lb_registro_nombreUsuario.Name = "lb_registro_nombreUsuario";
            lb_registro_nombreUsuario.Size = new Size(298, 78);
            lb_registro_nombreUsuario.TabIndex = 9;
            lb_registro_nombreUsuario.Text = "Nombre de usuario";
            lb_registro_nombreUsuario.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lb_registro_contraseña
            // 
            lb_registro_contraseña.AutoSize = true;
            lb_registro_contraseña.Dock = DockStyle.Fill;
            lb_registro_contraseña.Font = new Font("Cooper Black", 12F);
            lb_registro_contraseña.ForeColor = Color.FromArgb(39, 50, 56);
            lb_registro_contraseña.Location = new Point(3, 624);
            lb_registro_contraseña.Name = "lb_registro_contraseña";
            lb_registro_contraseña.Size = new Size(298, 78);
            lb_registro_contraseña.TabIndex = 10;
            lb_registro_contraseña.Text = "Contraseña de usuario";
            lb_registro_contraseña.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            label8.BackColor = Color.FromArgb(117, 230, 164);
            label8.Dock = DockStyle.Fill;
            label8.Font = new Font("Cooper Black", 25F);
            label8.ForeColor = Color.FromArgb(39, 50, 56);
            label8.Location = new Point(0, 0);
            label8.Margin = new Padding(0);
            label8.Name = "label8";
            label8.Size = new Size(1008, 106);
            label8.TabIndex = 1;
            label8.Text = "Registro de un nuevo empleado";
            label8.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // tlp3
            // 
            tlp3.BackColor = SystemColors.Control;
            tlp3.ColumnCount = 1;
            tlp3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlp3.Controls.Add(btn_baseDeDatos, 0, 1);
            tlp3.Controls.Add(btn_gestionarPedidos, 0, 2);
            tlp3.Controls.Add(btn_registrarEmpleado, 0, 3);
            tlp3.Controls.Add(btn_salirAlLogin, 0, 0);
            tlp3.Dock = DockStyle.Fill;
            tlp3.Location = new Point(0, 0);
            tlp3.Margin = new Padding(0);
            tlp3.Name = "tlp3";
            tlp3.RowCount = 4;
            tlp3.RowStyles.Add(new RowStyle(SizeType.Percent, 10F));
            tlp3.RowStyles.Add(new RowStyle(SizeType.Percent, 30F));
            tlp3.RowStyles.Add(new RowStyle(SizeType.Percent, 30F));
            tlp3.RowStyles.Add(new RowStyle(SizeType.Percent, 30F));
            tlp3.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tlp3.Size = new Size(140, 1069);
            tlp3.TabIndex = 0;
            // 
            // btn_baseDeDatos
            // 
            btn_baseDeDatos.BackColor = Color.FromArgb(117, 230, 164);
            btn_baseDeDatos.Dock = DockStyle.Fill;
            btn_baseDeDatos.FlatAppearance.BorderColor = Color.White;
            btn_baseDeDatos.FlatStyle = FlatStyle.Flat;
            btn_baseDeDatos.Font = new Font("Segoe UI", 8F, FontStyle.Bold);
            btn_baseDeDatos.ForeColor = Color.White;
            btn_baseDeDatos.Location = new Point(6, 111);
            btn_baseDeDatos.Margin = new Padding(6, 5, 6, 5);
            btn_baseDeDatos.Name = "btn_baseDeDatos";
            btn_baseDeDatos.Size = new Size(128, 310);
            btn_baseDeDatos.TabIndex = 3;
            btn_baseDeDatos.Text = "BASE DE DATOS";
            toolTip1.SetToolTip(btn_baseDeDatos, "Este es el menú para gestionar las bases de datos");
            btn_baseDeDatos.UseVisualStyleBackColor = false;
            btn_baseDeDatos.Click += btn_baseDeDatos_Click;
            // 
            // btn_gestionarPedidos
            // 
            btn_gestionarPedidos.BackColor = Color.FromArgb(117, 230, 164);
            btn_gestionarPedidos.Dock = DockStyle.Fill;
            btn_gestionarPedidos.FlatAppearance.BorderSize = 2;
            btn_gestionarPedidos.FlatStyle = FlatStyle.Flat;
            btn_gestionarPedidos.Font = new Font("Segoe UI", 8F, FontStyle.Bold);
            btn_gestionarPedidos.ForeColor = Color.White;
            btn_gestionarPedidos.Location = new Point(6, 431);
            btn_gestionarPedidos.Margin = new Padding(6, 5, 6, 5);
            btn_gestionarPedidos.Name = "btn_gestionarPedidos";
            btn_gestionarPedidos.Size = new Size(128, 310);
            btn_gestionarPedidos.TabIndex = 4;
            btn_gestionarPedidos.Text = "GESTIONAR PEDIDOS PENDIENTES";
            toolTip1.SetToolTip(btn_gestionarPedidos, "Este es el menú para aceptar o rechazar pedidos pendientes de revisión");
            btn_gestionarPedidos.UseVisualStyleBackColor = false;
            btn_gestionarPedidos.Click += btn_gestionarPedidos_Click;
            // 
            // btn_registrarEmpleado
            // 
            btn_registrarEmpleado.BackColor = Color.FromArgb(117, 230, 164);
            btn_registrarEmpleado.Dock = DockStyle.Fill;
            btn_registrarEmpleado.FlatAppearance.BorderSize = 2;
            btn_registrarEmpleado.FlatStyle = FlatStyle.Flat;
            btn_registrarEmpleado.Font = new Font("Segoe UI", 8F, FontStyle.Bold);
            btn_registrarEmpleado.ForeColor = Color.White;
            btn_registrarEmpleado.Location = new Point(6, 751);
            btn_registrarEmpleado.Margin = new Padding(6, 5, 6, 5);
            btn_registrarEmpleado.Name = "btn_registrarEmpleado";
            btn_registrarEmpleado.Size = new Size(128, 313);
            btn_registrarEmpleado.TabIndex = 5;
            btn_registrarEmpleado.Text = "REGISTRAR EMPLEADO";
            toolTip1.SetToolTip(btn_registrarEmpleado, "Menú para registrar un nuevo empleado");
            btn_registrarEmpleado.UseVisualStyleBackColor = false;
            btn_registrarEmpleado.Click += btn_registrarEmpleado_Click2;
            // 
            // btn_salirAlLogin
            // 
            btn_salirAlLogin.BackColor = Color.FromArgb(255, 128, 128);
            btn_salirAlLogin.Dock = DockStyle.Fill;
            btn_salirAlLogin.FlatAppearance.BorderColor = Color.White;
            btn_salirAlLogin.FlatAppearance.BorderSize = 2;
            btn_salirAlLogin.FlatStyle = FlatStyle.Flat;
            btn_salirAlLogin.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btn_salirAlLogin.ForeColor = Color.White;
            btn_salirAlLogin.Location = new Point(6, 0);
            btn_salirAlLogin.Margin = new Padding(6, 0, 6, 5);
            btn_salirAlLogin.Name = "btn_salirAlLogin";
            btn_salirAlLogin.Size = new Size(128, 101);
            btn_salirAlLogin.TabIndex = 6;
            btn_salirAlLogin.Text = "SALIR";
            toolTip1.SetToolTip(btn_salirAlLogin, "Salir al menú de login");
            btn_salirAlLogin.UseVisualStyleBackColor = false;
            btn_salirAlLogin.Click += btn_salirAlLogin_Click;
            // 
            // btn_salir
            // 
            btn_salir.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btn_salir.BackColor = Color.FromArgb(117, 230, 164);
            btn_salir.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btn_salir.ForeColor = Color.White;
            btn_salir.Location = new Point(1103, 3);
            btn_salir.Name = "btn_salir";
            btn_salir.Size = new Size(42, 40);
            btn_salir.TabIndex = 1;
            btn_salir.Text = "X";
            btn_salir.UseVisualStyleBackColor = false;
            btn_salir.Click += btn_salir_Click;
            // 
            // tlp4
            // 
            tlp4.ColumnCount = 3;
            tlp4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40F));
            tlp4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30F));
            tlp4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30F));
            tlp4.Controls.Add(tlp5, 2, 0);
            tlp4.Controls.Add(labelHora, 1, 0);
            tlp4.Dock = DockStyle.Fill;
            tlp4.Location = new Point(0, 46);
            tlp4.Margin = new Padding(0);
            tlp4.Name = "tlp4";
            tlp4.RowCount = 1;
            tlp4.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tlp4.Size = new Size(1148, 46);
            tlp4.TabIndex = 3;
            // 
            // tlp5
            // 
            tlp5.BackColor = Color.FromArgb(117, 230, 164);
            tlp5.BackgroundImageLayout = ImageLayout.Center;
            tlp5.ColumnCount = 2;
            tlp5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 15F));
            tlp5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 85F));
            tlp5.Controls.Add(pictureBox1, 0, 0);
            tlp5.Controls.Add(label_nombreUsuario, 1, 0);
            tlp5.Dock = DockStyle.Fill;
            tlp5.Location = new Point(808, 5);
            tlp5.Margin = new Padding(5);
            tlp5.Name = "tlp5";
            tlp5.RowCount = 2;
            tlp5.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tlp5.RowStyles.Add(new RowStyle(SizeType.Percent, 0F));
            tlp5.Size = new Size(335, 36);
            tlp5.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.FromArgb(117, 230, 164);
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Margin = new Padding(0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(50, 36);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // label_nombreUsuario
            // 
            label_nombreUsuario.AutoSize = true;
            label_nombreUsuario.BackColor = SystemColors.Control;
            label_nombreUsuario.Dock = DockStyle.Fill;
            label_nombreUsuario.Font = new Font("Segoe UI", 9F);
            label_nombreUsuario.Location = new Point(50, 0);
            label_nombreUsuario.Margin = new Padding(0);
            label_nombreUsuario.Name = "label_nombreUsuario";
            label_nombreUsuario.Padding = new Padding(10, 0, 0, 0);
            label_nombreUsuario.Size = new Size(285, 36);
            label_nombreUsuario.TabIndex = 1;
            label_nombreUsuario.Text = "Nombre del empleado";
            label_nombreUsuario.TextAlign = ContentAlignment.MiddleLeft;
            toolTip1.SetToolTip(label_nombreUsuario, "Nombre del empleado");
            // 
            // labelHora
            // 
            labelHora.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            labelHora.AutoSize = true;
            labelHora.BackColor = Color.Navy;
            labelHora.FlatStyle = FlatStyle.System;
            labelHora.Font = new Font("Segoe UI", 9F);
            labelHora.ForeColor = Color.Yellow;
            labelHora.Location = new Point(544, 20);
            labelHora.Margin = new Padding(85, 20, 85, 0);
            labelHora.Name = "labelHora";
            labelHora.Size = new Size(174, 20);
            labelHora.TabIndex = 4;
            labelHora.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // tlp6
            // 
            tlp6.BackColor = SystemColors.ActiveCaption;
            tlp6.ColumnCount = 2;
            tlp6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tlp6.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tlp6.Dock = DockStyle.Fill;
            tlp6.Location = new Point(0, 0);
            tlp6.Name = "tlp6";
            tlp6.RowCount = 2;
            tlp6.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tlp6.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tlp6.Size = new Size(200, 100);
            tlp6.TabIndex = 0;
            // 
            // timer1
            // 
            timer1.Enabled = true;
            timer1.Interval = 1000;
            timer1.Tick += timer1_tick;
            // 
            // tlp8
            // 
            tlp8.ColumnCount = 2;
            tlp8.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tlp8.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tlp8.Dock = DockStyle.Fill;
            tlp8.Location = new Point(0, 0);
            tlp8.Name = "tlp8";
            tlp8.RowCount = 1;
            tlp8.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tlp8.Size = new Size(200, 100);
            tlp8.TabIndex = 0;
            // 
            // tlp9
            // 
            tlp9.ColumnCount = 1;
            tlp9.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlp9.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tlp9.Controls.Add(textBox1, 0, 1);
            tlp9.Controls.Add(textBox2, 0, 3);
            tlp9.Controls.Add(textBox3, 0, 5);
            tlp9.Controls.Add(textBox4, 0, 7);
            tlp9.Controls.Add(textBox5, 0, 9);
            tlp9.Controls.Add(textBox6, 0, 11);
            tlp9.Dock = DockStyle.Fill;
            tlp9.Location = new Point(100, 50);
            tlp9.Margin = new Padding(100, 50, 100, 50);
            tlp9.Name = "tlp9";
            tlp9.RowCount = 12;
            tlp9.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333335F));
            tlp9.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333335F));
            tlp9.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333335F));
            tlp9.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333335F));
            tlp9.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333335F));
            tlp9.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333335F));
            tlp9.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333335F));
            tlp9.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333335F));
            tlp9.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333335F));
            tlp9.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333335F));
            tlp9.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333335F));
            tlp9.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333335F));
            tlp9.Size = new Size(1, 651);
            tlp9.TabIndex = 0;
            // 
            // textBox1
            // 
            textBox1.Dock = DockStyle.Fill;
            textBox1.Location = new Point(3, 57);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(1, 27);
            textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            textBox2.Dock = DockStyle.Fill;
            textBox2.Location = new Point(3, 165);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(1, 27);
            textBox2.TabIndex = 1;
            // 
            // textBox3
            // 
            textBox3.Dock = DockStyle.Fill;
            textBox3.Location = new Point(3, 273);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(1, 27);
            textBox3.TabIndex = 2;
            // 
            // textBox4
            // 
            textBox4.Dock = DockStyle.Fill;
            textBox4.Location = new Point(3, 381);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(1, 27);
            textBox4.TabIndex = 3;
            // 
            // textBox5
            // 
            textBox5.Dock = DockStyle.Fill;
            textBox5.Location = new Point(3, 489);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(1, 27);
            textBox5.TabIndex = 4;
            // 
            // textBox6
            // 
            textBox6.Dock = DockStyle.Fill;
            textBox6.Location = new Point(3, 597);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(1, 27);
            textBox6.TabIndex = 5;
            // 
            // tlp11
            // 
            tlp11.ColumnCount = 1;
            tlp11.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlp11.Controls.Add(label2, 0, 0);
            tlp11.Controls.Add(label3, 0, 2);
            tlp11.Controls.Add(label4, 0, 4);
            tlp11.Controls.Add(label5, 0, 6);
            tlp11.Controls.Add(label6, 0, 8);
            tlp11.Controls.Add(label7, 0, 10);
            tlp11.Controls.Add(textBox7, 0, 1);
            tlp11.Controls.Add(textBox8, 0, 3);
            tlp11.Controls.Add(textBox9, 0, 5);
            tlp11.Controls.Add(textBox10, 0, 7);
            tlp11.Controls.Add(textBox11, 0, 9);
            tlp11.Controls.Add(textBox12, 0, 11);
            tlp11.Dock = DockStyle.Fill;
            tlp11.Location = new Point(100, 40);
            tlp11.Margin = new Padding(150, 0, 150, 50);
            tlp11.Name = "tlp11";
            tlp11.RowCount = 12;
            tlp11.RowStyles.Add(new RowStyle(SizeType.Percent, 8.330276F));
            tlp11.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333611F));
            tlp11.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333611F));
            tlp11.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333611F));
            tlp11.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333611F));
            tlp11.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333611F));
            tlp11.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333611F));
            tlp11.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333611F));
            tlp11.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333611F));
            tlp11.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333611F));
            tlp11.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333611F));
            tlp11.RowStyles.Add(new RowStyle(SizeType.Percent, 8.333611F));
            tlp11.Size = new Size(370, 528);
            tlp11.TabIndex = 0;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Dock = DockStyle.Fill;
            label2.Location = new Point(3, 0);
            label2.Name = "label2";
            label2.Size = new Size(364, 43);
            label2.TabIndex = 0;
            label2.Text = "Nombre del empleado";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Dock = DockStyle.Fill;
            label3.Location = new Point(3, 87);
            label3.Name = "label3";
            label3.Size = new Size(364, 44);
            label3.TabIndex = 1;
            label3.Text = "Primer apellido";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Dock = DockStyle.Fill;
            label4.Location = new Point(3, 175);
            label4.Name = "label4";
            label4.Size = new Size(364, 44);
            label4.TabIndex = 2;
            label4.Text = "Segundo apellido";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Dock = DockStyle.Fill;
            label5.Location = new Point(3, 263);
            label5.Name = "label5";
            label5.Size = new Size(364, 44);
            label5.TabIndex = 3;
            label5.Text = "DNI / NIE";
            label5.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Dock = DockStyle.Fill;
            label6.Location = new Point(3, 351);
            label6.Name = "label6";
            label6.Size = new Size(364, 44);
            label6.TabIndex = 4;
            label6.Text = "Número de teléfono";
            label6.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Dock = DockStyle.Fill;
            label7.Location = new Point(3, 439);
            label7.Name = "label7";
            label7.Size = new Size(364, 44);
            label7.TabIndex = 5;
            label7.Text = "Correo electrónico";
            label7.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // textBox7
            // 
            textBox7.Dock = DockStyle.Fill;
            textBox7.Location = new Point(30, 43);
            textBox7.Margin = new Padding(30, 0, 30, 0);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(310, 27);
            textBox7.TabIndex = 6;
            // 
            // textBox8
            // 
            textBox8.Dock = DockStyle.Fill;
            textBox8.Location = new Point(30, 131);
            textBox8.Margin = new Padding(30, 0, 30, 0);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(310, 27);
            textBox8.TabIndex = 7;
            // 
            // textBox9
            // 
            textBox9.Dock = DockStyle.Fill;
            textBox9.Location = new Point(30, 219);
            textBox9.Margin = new Padding(30, 0, 30, 0);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(310, 27);
            textBox9.TabIndex = 8;
            // 
            // textBox10
            // 
            textBox10.Dock = DockStyle.Fill;
            textBox10.Location = new Point(30, 307);
            textBox10.Margin = new Padding(30, 0, 30, 0);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(310, 27);
            textBox10.TabIndex = 9;
            // 
            // textBox11
            // 
            textBox11.Dock = DockStyle.Fill;
            textBox11.Location = new Point(30, 395);
            textBox11.Margin = new Padding(30, 0, 30, 0);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(310, 27);
            textBox11.TabIndex = 10;
            // 
            // textBox12
            // 
            textBox12.Dock = DockStyle.Fill;
            textBox12.Location = new Point(30, 483);
            textBox12.Margin = new Padding(30, 0, 30, 0);
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(310, 27);
            textBox12.TabIndex = 11;
            // 
            // menuBaseDeDatos
            // 
            menuBaseDeDatos.AllowDrop = true;
            menuBaseDeDatos.Controls.Add(tabPageEmpleados);
            menuBaseDeDatos.Controls.Add(tabPageClientes);
            menuBaseDeDatos.Controls.Add(tabPageUsuarios);
            menuBaseDeDatos.Controls.Add(tabPagePedidos);
            menuBaseDeDatos.Controls.Add(tabPageCoches);
            menuBaseDeDatos.Controls.Add(tabPageServicios);
            menuBaseDeDatos.Controls.Add(tabPageTalleres);
            menuBaseDeDatos.Controls.Add(tabPageRoles);
            menuBaseDeDatos.Location = new Point(145, 94);
            menuBaseDeDatos.Margin = new Padding(5);
            menuBaseDeDatos.Name = "menuBaseDeDatos";
            menuBaseDeDatos.SelectedIndex = 0;
            menuBaseDeDatos.Size = new Size(1008, 1072);
            menuBaseDeDatos.TabIndex = 2;
            // 
            // tabPageEmpleados
            // 
            tabPageEmpleados.Controls.Add(ucPanel_tipoa_empleados);
            tabPageEmpleados.Location = new Point(4, 29);
            tabPageEmpleados.Name = "tabPageEmpleados";
            tabPageEmpleados.Size = new Size(1000, 1039);
            tabPageEmpleados.TabIndex = 2;
            tabPageEmpleados.Text = "EMPLEADOS";
            tabPageEmpleados.UseVisualStyleBackColor = true;
            // 
            // ucPanel_tipoa_empleados
            // 
            ucPanel_tipoa_empleados.AllowDrop = true;
            ucPanel_tipoa_empleados.Dock = DockStyle.Fill;
            ucPanel_tipoa_empleados.ForeColor = Color.FromArgb(39, 50, 56);
            ucPanel_tipoa_empleados.ImeMode = ImeMode.On;
            ucPanel_tipoa_empleados.Location = new Point(0, 0);
            ucPanel_tipoa_empleados.Margin = new Padding(11, 13, 11, 13);
            ucPanel_tipoa_empleados.Name = "ucPanel_tipoa_empleados";
            ucPanel_tipoa_empleados.Size = new Size(1000, 1039);
            ucPanel_tipoa_empleados.TabIndex = 0;
            ucPanel_tipoa_empleados.Visible = false;
            // 
            // tabPageClientes
            // 
            tabPageClientes.Controls.Add(ucPanel_tipoa_clientes);
            tabPageClientes.Font = new Font("Segoe UI", 9F);
            tabPageClientes.Location = new Point(4, 29);
            tabPageClientes.Name = "tabPageClientes";
            tabPageClientes.Size = new Size(1000, 1039);
            tabPageClientes.TabIndex = 0;
            tabPageClientes.Text = "CLIENTES";
            tabPageClientes.UseVisualStyleBackColor = true;
            // 
            // ucPanel_tipoa_clientes
            // 
            ucPanel_tipoa_clientes.AllowDrop = true;
            ucPanel_tipoa_clientes.Dock = DockStyle.Fill;
            ucPanel_tipoa_clientes.ImeMode = ImeMode.On;
            ucPanel_tipoa_clientes.Location = new Point(0, 0);
            ucPanel_tipoa_clientes.Margin = new Padding(11, 13, 11, 13);
            ucPanel_tipoa_clientes.Name = "ucPanel_tipoa_clientes";
            ucPanel_tipoa_clientes.Size = new Size(1000, 1039);
            ucPanel_tipoa_clientes.TabIndex = 0;
            // 
            // tabPageUsuarios
            // 
            tabPageUsuarios.Controls.Add(ucPanel_tipoa_usuarios);
            tabPageUsuarios.Location = new Point(4, 29);
            tabPageUsuarios.Name = "tabPageUsuarios";
            tabPageUsuarios.Size = new Size(1000, 1039);
            tabPageUsuarios.TabIndex = 7;
            tabPageUsuarios.Text = "USUARIOS";
            tabPageUsuarios.UseVisualStyleBackColor = true;
            // 
            // ucPanel_tipoa_usuarios
            // 
            ucPanel_tipoa_usuarios.AllowDrop = true;
            ucPanel_tipoa_usuarios.Dock = DockStyle.Fill;
            ucPanel_tipoa_usuarios.ImeMode = ImeMode.On;
            ucPanel_tipoa_usuarios.Location = new Point(0, 0);
            ucPanel_tipoa_usuarios.Margin = new Padding(11, 13, 11, 13);
            ucPanel_tipoa_usuarios.Name = "ucPanel_tipoa_usuarios";
            ucPanel_tipoa_usuarios.Size = new Size(1000, 1039);
            ucPanel_tipoa_usuarios.TabIndex = 0;
            // 
            // tabPagePedidos
            // 
            tabPagePedidos.Controls.Add(ucPanel_tipoa_pedidos);
            tabPagePedidos.Location = new Point(4, 29);
            tabPagePedidos.Name = "tabPagePedidos";
            tabPagePedidos.Size = new Size(1000, 1039);
            tabPagePedidos.TabIndex = 3;
            tabPagePedidos.Text = "PEDIDOS";
            tabPagePedidos.UseVisualStyleBackColor = true;
            // 
            // ucPanel_tipoa_pedidos
            // 
            ucPanel_tipoa_pedidos.AllowDrop = true;
            ucPanel_tipoa_pedidos.Dock = DockStyle.Fill;
            ucPanel_tipoa_pedidos.ImeMode = ImeMode.On;
            ucPanel_tipoa_pedidos.Location = new Point(0, 0);
            ucPanel_tipoa_pedidos.Margin = new Padding(11, 13, 11, 13);
            ucPanel_tipoa_pedidos.Name = "ucPanel_tipoa_pedidos";
            ucPanel_tipoa_pedidos.Size = new Size(1000, 1039);
            ucPanel_tipoa_pedidos.TabIndex = 0;
            // 
            // tabPageCoches
            // 
            tabPageCoches.Controls.Add(ucPanel_tipoa_coches);
            tabPageCoches.Location = new Point(4, 29);
            tabPageCoches.Name = "tabPageCoches";
            tabPageCoches.Size = new Size(1000, 1039);
            tabPageCoches.TabIndex = 1;
            tabPageCoches.Text = "COCHES";
            tabPageCoches.UseVisualStyleBackColor = true;
            // 
            // ucPanel_tipoa_coches
            // 
            ucPanel_tipoa_coches.AllowDrop = true;
            ucPanel_tipoa_coches.Dock = DockStyle.Fill;
            ucPanel_tipoa_coches.ImeMode = ImeMode.On;
            ucPanel_tipoa_coches.Location = new Point(0, 0);
            ucPanel_tipoa_coches.Margin = new Padding(11, 13, 11, 13);
            ucPanel_tipoa_coches.Name = "ucPanel_tipoa_coches";
            ucPanel_tipoa_coches.Size = new Size(1000, 1039);
            ucPanel_tipoa_coches.TabIndex = 0;
            // 
            // tabPageServicios
            // 
            tabPageServicios.Controls.Add(ucPanel_tipoa_servicios);
            tabPageServicios.Location = new Point(4, 29);
            tabPageServicios.Name = "tabPageServicios";
            tabPageServicios.Size = new Size(1000, 1039);
            tabPageServicios.TabIndex = 5;
            tabPageServicios.Text = "SERVICIOS";
            tabPageServicios.UseVisualStyleBackColor = true;
            // 
            // ucPanel_tipoa_servicios
            // 
            ucPanel_tipoa_servicios.AllowDrop = true;
            ucPanel_tipoa_servicios.Dock = DockStyle.Fill;
            ucPanel_tipoa_servicios.ImeMode = ImeMode.On;
            ucPanel_tipoa_servicios.Location = new Point(0, 0);
            ucPanel_tipoa_servicios.Margin = new Padding(11, 13, 11, 13);
            ucPanel_tipoa_servicios.Name = "ucPanel_tipoa_servicios";
            ucPanel_tipoa_servicios.Size = new Size(1000, 1039);
            ucPanel_tipoa_servicios.TabIndex = 0;
            // 
            // tabPageTalleres
            // 
            tabPageTalleres.Controls.Add(ucPanel_tipoa_talleres);
            tabPageTalleres.Location = new Point(4, 29);
            tabPageTalleres.Name = "tabPageTalleres";
            tabPageTalleres.Size = new Size(1000, 1039);
            tabPageTalleres.TabIndex = 6;
            tabPageTalleres.Text = "TALLERES";
            tabPageTalleres.UseVisualStyleBackColor = true;
            // 
            // ucPanel_tipoa_talleres
            // 
            ucPanel_tipoa_talleres.AllowDrop = true;
            ucPanel_tipoa_talleres.Dock = DockStyle.Fill;
            ucPanel_tipoa_talleres.ImeMode = ImeMode.On;
            ucPanel_tipoa_talleres.Location = new Point(0, 0);
            ucPanel_tipoa_talleres.Margin = new Padding(11, 13, 11, 13);
            ucPanel_tipoa_talleres.Name = "ucPanel_tipoa_talleres";
            ucPanel_tipoa_talleres.Size = new Size(1000, 1039);
            ucPanel_tipoa_talleres.TabIndex = 0;
            // 
            // tabPageRoles
            // 
            tabPageRoles.Controls.Add(ucPanel_tipoa_roles);
            tabPageRoles.Location = new Point(4, 29);
            tabPageRoles.Name = "tabPageRoles";
            tabPageRoles.Size = new Size(1000, 1039);
            tabPageRoles.TabIndex = 4;
            tabPageRoles.Text = "ROLES";
            tabPageRoles.UseVisualStyleBackColor = true;
            // 
            // ucPanel_tipoa_roles
            // 
            ucPanel_tipoa_roles.AllowDrop = true;
            ucPanel_tipoa_roles.Dock = DockStyle.Fill;
            ucPanel_tipoa_roles.ImeMode = ImeMode.On;
            ucPanel_tipoa_roles.Location = new Point(0, 0);
            ucPanel_tipoa_roles.Margin = new Padding(11, 13, 11, 13);
            ucPanel_tipoa_roles.Name = "ucPanel_tipoa_roles";
            ucPanel_tipoa_roles.Size = new Size(1000, 1039);
            ucPanel_tipoa_roles.TabIndex = 0;
            // 
            // menuGestionarPedidos
            // 
            menuGestionarPedidos.BackColor = SystemColors.Control;
            menuGestionarPedidos.ColumnCount = 1;
            menuGestionarPedidos.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            menuGestionarPedidos.Controls.Add(dataGridView_pedidosPendientes, 0, 2);
            menuGestionarPedidos.Controls.Add(tableLayoutPanel1, 0, 3);
            menuGestionarPedidos.Controls.Add(label9, 0, 1);
            menuGestionarPedidos.Controls.Add(button1, 0, 0);
            menuGestionarPedidos.Location = new Point(145, 94);
            menuGestionarPedidos.Name = "menuGestionarPedidos";
            menuGestionarPedidos.RowCount = 4;
            menuGestionarPedidos.RowStyles.Add(new RowStyle(SizeType.Percent, 7.27272749F));
            menuGestionarPedidos.RowStyles.Add(new RowStyle(SizeType.Percent, 10.909091F));
            menuGestionarPedidos.RowStyles.Add(new RowStyle(SizeType.Percent, 45.4545441F));
            menuGestionarPedidos.RowStyles.Add(new RowStyle(SizeType.Percent, 36.363636F));
            menuGestionarPedidos.Size = new Size(1008, 1069);
            menuGestionarPedidos.TabIndex = 3;
            // 
            // dataGridView_pedidosPendientes
            // 
            dataGridView_pedidosPendientes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView_pedidosPendientes.Dock = DockStyle.Fill;
            dataGridView_pedidosPendientes.Location = new Point(30, 243);
            dataGridView_pedidosPendientes.Margin = new Padding(30, 50, 30, 50);
            dataGridView_pedidosPendientes.Name = "dataGridView_pedidosPendientes";
            dataGridView_pedidosPendientes.RowHeadersWidth = 51;
            dataGridView_pedidosPendientes.Size = new Size(948, 385);
            dataGridView_pedidosPendientes.TabIndex = 0;
            dataGridView_pedidosPendientes.CellClick += dataGridView1_CellClick;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.Controls.Add(btn_aceptarPedidoPendiente, 0, 0);
            tableLayoutPanel1.Controls.Add(btn_rechazarPedidoPendiente, 1, 0);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(100, 678);
            tableLayoutPanel1.Margin = new Padding(100, 0, 100, 200);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.Size = new Size(808, 191);
            tableLayoutPanel1.TabIndex = 1;
            // 
            // btn_aceptarPedidoPendiente
            // 
            btn_aceptarPedidoPendiente.BackColor = Color.FromArgb(117, 230, 164);
            btn_aceptarPedidoPendiente.Dock = DockStyle.Fill;
            btn_aceptarPedidoPendiente.FlatAppearance.BorderColor = Color.FromArgb(0, 64, 64);
            btn_aceptarPedidoPendiente.FlatStyle = FlatStyle.Flat;
            btn_aceptarPedidoPendiente.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btn_aceptarPedidoPendiente.ForeColor = Color.FromArgb(0, 64, 64);
            btn_aceptarPedidoPendiente.Location = new Point(5, 5);
            btn_aceptarPedidoPendiente.Margin = new Padding(5);
            btn_aceptarPedidoPendiente.Name = "btn_aceptarPedidoPendiente";
            btn_aceptarPedidoPendiente.Size = new Size(394, 181);
            btn_aceptarPedidoPendiente.TabIndex = 0;
            btn_aceptarPedidoPendiente.Text = "ACEPTAR PEDIDO";
            btn_aceptarPedidoPendiente.UseVisualStyleBackColor = false;
            btn_aceptarPedidoPendiente.Click += btn_aceptarPedidoPendiente_Click;
            // 
            // btn_rechazarPedidoPendiente
            // 
            btn_rechazarPedidoPendiente.BackColor = Color.FromArgb(255, 128, 128);
            btn_rechazarPedidoPendiente.Dock = DockStyle.Fill;
            btn_rechazarPedidoPendiente.FlatAppearance.BorderColor = Color.FromArgb(174, 0, 4);
            btn_rechazarPedidoPendiente.FlatStyle = FlatStyle.Flat;
            btn_rechazarPedidoPendiente.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btn_rechazarPedidoPendiente.ForeColor = Color.FromArgb(174, 0, 4);
            btn_rechazarPedidoPendiente.Location = new Point(409, 5);
            btn_rechazarPedidoPendiente.Margin = new Padding(5);
            btn_rechazarPedidoPendiente.Name = "btn_rechazarPedidoPendiente";
            btn_rechazarPedidoPendiente.Size = new Size(394, 181);
            btn_rechazarPedidoPendiente.TabIndex = 1;
            btn_rechazarPedidoPendiente.Text = "RECHAZAR PEDIDO";
            btn_rechazarPedidoPendiente.UseVisualStyleBackColor = false;
            btn_rechazarPedidoPendiente.Click += btn_rechazarPedidoPendiente_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Dock = DockStyle.Bottom;
            label9.Font = new Font("Cooper Black", 25F);
            label9.ForeColor = Color.FromArgb(39, 50, 56);
            label9.Location = new Point(3, 144);
            label9.Name = "label9";
            label9.Size = new Size(1002, 49);
            label9.TabIndex = 2;
            label9.Text = "Gestionar pedidos pendientes";
            label9.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(223, 248, 229);
            button1.BackgroundImage = (Image)resources.GetObject("button1.BackgroundImage");
            button1.BackgroundImageLayout = ImageLayout.Zoom;
            button1.Dock = DockStyle.Fill;
            button1.Location = new Point(950, 25);
            button1.Margin = new Padding(950, 25, 0, 0);
            button1.Name = "button1";
            button1.Size = new Size(58, 52);
            button1.TabIndex = 3;
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // panelBienvenida
            // 
            panelBienvenida.BackColor = SystemColors.Control;
            panelBienvenida.Controls.Add(tableLayoutPanel2);
            panelBienvenida.Location = new Point(145, 95);
            panelBienvenida.Name = "panelBienvenida";
            panelBienvenida.Size = new Size(1008, 1068);
            panelBienvenida.TabIndex = 5;
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 1;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel2.Controls.Add(btn_info, 0, 1);
            tableLayoutPanel2.Controls.Add(label_bienvenida, 0, 0);
            tableLayoutPanel2.Dock = DockStyle.Fill;
            tableLayoutPanel2.Location = new Point(0, 0);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 2;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 95F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 5F));
            tableLayoutPanel2.Size = new Size(1008, 1068);
            tableLayoutPanel2.TabIndex = 0;
            // 
            // btn_info
            // 
            btn_info.BackColor = Color.FromArgb(223, 248, 229);
            btn_info.BackgroundImage = (Image)resources.GetObject("btn_info.BackgroundImage");
            btn_info.BackgroundImageLayout = ImageLayout.Zoom;
            btn_info.Dock = DockStyle.Fill;
            btn_info.FlatStyle = FlatStyle.Flat;
            btn_info.ImeMode = ImeMode.NoControl;
            btn_info.Location = new Point(940, 1019);
            btn_info.Margin = new Padding(940, 5, 15, 5);
            btn_info.Name = "btn_info";
            btn_info.Size = new Size(53, 44);
            btn_info.TabIndex = 6;
            btn_info.UseVisualStyleBackColor = false;
            btn_info.Click += btn_info_Click;
            // 
            // label_bienvenida
            // 
            label_bienvenida.AutoSize = true;
            label_bienvenida.Dock = DockStyle.Fill;
            label_bienvenida.Font = new Font("Cooper Black", 30F);
            label_bienvenida.ForeColor = Color.FromArgb(39, 50, 56);
            label_bienvenida.Location = new Point(3, 0);
            label_bienvenida.Name = "label_bienvenida";
            label_bienvenida.Size = new Size(1002, 1014);
            label_bienvenida.TabIndex = 7;
            label_bienvenida.Text = "Bienvenida";
            label_bienvenida.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Form_Empleado
            // 
            AllowDrop = true;
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1158, 1171);
            Controls.Add(panelBienvenida);
            Controls.Add(menuGestionarPedidos);
            Controls.Add(menuBaseDeDatos);
            Controls.Add(tlp1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 4, 3, 4);
            Name = "Form_Empleado";
            Padding = new Padding(5);
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            tlp1.ResumeLayout(false);
            tlp2.ResumeLayout(false);
            menuRegistrarEmpleado.ResumeLayout(false);
            tlp10.ResumeLayout(false);
            tlp12.ResumeLayout(false);
            tlp12.PerformLayout();
            tlp7.ResumeLayout(false);
            tlp7.PerformLayout();
            tlp3.ResumeLayout(false);
            tlp4.ResumeLayout(false);
            tlp4.PerformLayout();
            tlp5.ResumeLayout(false);
            tlp5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            tlp9.ResumeLayout(false);
            tlp9.PerformLayout();
            tlp11.ResumeLayout(false);
            tlp11.PerformLayout();
            menuBaseDeDatos.ResumeLayout(false);
            tabPageEmpleados.ResumeLayout(false);
            tabPageClientes.ResumeLayout(false);
            tabPageUsuarios.ResumeLayout(false);
            tabPagePedidos.ResumeLayout(false);
            tabPageCoches.ResumeLayout(false);
            tabPageServicios.ResumeLayout(false);
            tabPageTalleres.ResumeLayout(false);
            tabPageRoles.ResumeLayout(false);
            menuGestionarPedidos.ResumeLayout(false);
            menuGestionarPedidos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView_pedidosPendientes).EndInit();
            tableLayoutPanel1.ResumeLayout(false);
            panelBienvenida.ResumeLayout(false);
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tlp1;
        private Button btn_salir;
        private TableLayoutPanel tlp2;
        private TableLayoutPanel tlp3;
        private Button btn_baseDeDatos;
        private Button btn_gestionarPedidos;
        private Button btn_registrarEmpleado;
        private TableLayoutPanel tlp4;
        private TableLayoutPanel tlp5;
        private TableLayoutPanel tlp6;
        private PictureBox pictureBox1;
        private Label label_nombreUsuario;
        private Button btn_salirAlLogin;
        private System.Windows.Forms.Timer timer1;
        private Label labelHora;
        private TableLayoutPanel tlp8;
        private TableLayoutPanel tlp9;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox textBox6;
        private TableLayoutPanel tlp11;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private TextBox textBox7;
        private TextBox textBox8;
        private TextBox textBox9;
        private TextBox textBox10;
        private TextBox textBox11;
        private TextBox textBox12;
        private TabControl menuBaseDeDatos;
        private TabPage tabPageEmpleados;
        private TabPage tabPageClientes;
        private UCPanel_tipoA ucPanel_tipoa_clientes;
        private TabPage tabPageCoches;
        private UCPanel_tipoA ucPanel_tipoa_coches;
        private TabPage tabPagePedidos;
        private UCPanel_tipoA ucPanel_tipoa_pedidos;
        private TabPage tabPageRoles;
        private UCPanel_tipoA ucPanel_tipoa_roles;
        private TabPage tabPageServicios;
        private UCPanel_tipoA ucPanel_tipoa_servicios;
        private TabPage tabPageTalleres;
        private UCPanel_tipoA ucPanel_tipoa_talleres;
        public UCPanel_tipoA ucPanel_tipoa_empleados;
        private TableLayoutPanel menuRegistrarEmpleado;
        private TableLayoutPanel tlp10;
        private TableLayoutPanel tlp12;
        private Label lb_registro_nombre;
        private Label lb_registro_primerApellido;
        private Label lb_registro_segundoApellido;
        private Label lb_registro_dniNie;
        private Label lb_registro_telefono;
        private Label lb_registro_correo;
        private TableLayoutPanel tlp7;
        private Button btn_registrarEmpleado_crearEmpleado;
        private Label lb_registro_salarioBaseç;
        private Label lb_registro_salarioExtra;
        private Label lb_registro_fechaInicioContracto;
        private Label lb_registro_nombreUsuario;
        private Label lb_registro_contraseña;
        private Label label8;
        public TableLayoutPanel menuGestionarPedidos;
        private TabPage tabPageUsuarios;
        private UCPanel_tipoA ucPanel_tipoa_usuarios;
        public TextBox textbox_re_nombre;
        public TextBox textbox_re_primerApellido;
        public TextBox textbox_re_segundoApellido;
        public TextBox textbox_re_dni;
        public TextBox textbox_re_telefono;
        public TextBox textbox_re_correo;
        public TextBox textbox_re_salarioBase;
        public TextBox textbox_re_salarioExtra;
        public TextBox textbox_re_fechaInicioContrato;
        public TextBox textbox_re_nombreUsuario;
        public TextBox textbox_re_contraseñaUsuario;
        private TableLayoutPanel tableLayoutPanel1;
        private Label label9;
        public DataGridView dataGridView_pedidosPendientes;
        public Button btn_aceptarPedidoPendiente;
        public Button btn_rechazarPedidoPendiente;
        private Panel panelBienvenida;
        private ToolTip toolTip1;
        private TableLayoutPanel tableLayoutPanel2;
        private Button btn_info;
        private Label label_bienvenida;
        private Button button1;
    }
}
