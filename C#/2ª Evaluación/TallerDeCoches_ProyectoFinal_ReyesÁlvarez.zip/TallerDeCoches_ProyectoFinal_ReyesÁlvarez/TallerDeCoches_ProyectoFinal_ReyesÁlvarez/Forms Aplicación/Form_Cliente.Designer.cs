﻿namespace TallerDeCoches_ProyectoFinal_ReyesÁlvarez.Forms_Identificación
{
    partial class Form_Cliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Cliente));
            panel1 = new Panel();
            tlp1 = new TableLayoutPanel();
            tlp2 = new TableLayoutPanel();
            tableLayoutPanel2 = new TableLayoutPanel();
            tlp_serviciosEspeciales = new TableLayoutPanel();
            button24 = new Button();
            button25 = new Button();
            button26 = new Button();
            button27 = new Button();
            button28 = new Button();
            button29 = new Button();
            tlp_reparacion = new TableLayoutPanel();
            button18 = new Button();
            button19 = new Button();
            button20 = new Button();
            button21 = new Button();
            button22 = new Button();
            button23 = new Button();
            tlp_mantenimiento = new TableLayoutPanel();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            button17 = new Button();
            tlp_lavadoDetallado = new TableLayoutPanel();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            label1 = new Label();
            tableLayoutPanel1 = new TableLayoutPanel();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            tlpTarjeta = new TableLayoutPanel();
            tableLayoutPanel7 = new TableLayoutPanel();
            tableLayoutPanel8 = new TableLayoutPanel();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            labelSE_Servicio = new Label();
            labelSE_Taller = new Label();
            labelSE_ImporteBruto = new Label();
            labelSE_TipoImpositivo = new Label();
            button5 = new Button();
            pboxFamilia = new PictureBox();
            btn_salir = new Button();
            tableLayoutPanel3 = new TableLayoutPanel();
            toolTip1 = new ToolTip(components);
            pictureBox2 = new PictureBox();
            label_nombreUsuario2 = new Label();
            panel1.SuspendLayout();
            tlp1.SuspendLayout();
            tlp2.SuspendLayout();
            tableLayoutPanel2.SuspendLayout();
            tlp_serviciosEspeciales.SuspendLayout();
            tlp_reparacion.SuspendLayout();
            tlp_mantenimiento.SuspendLayout();
            tlp_lavadoDetallado.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            tlpTarjeta.SuspendLayout();
            tableLayoutPanel7.SuspendLayout();
            tableLayoutPanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pboxFamilia).BeginInit();
            tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ActiveCaptionText;
            panel1.Controls.Add(tlp1);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1140, 1124);
            panel1.TabIndex = 0;
            // 
            // tlp1
            // 
            tlp1.AllowDrop = true;
            tlp1.BackColor = Color.FromArgb(117, 230, 164);
            tlp1.ColumnCount = 1;
            tlp1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlp1.Controls.Add(tlp2, 0, 2);
            tlp1.Controls.Add(btn_salir, 0, 0);
            tlp1.Controls.Add(tableLayoutPanel3, 0, 1);
            tlp1.Dock = DockStyle.Fill;
            tlp1.Location = new Point(0, 0);
            tlp1.Margin = new Padding(0);
            tlp1.Name = "tlp1";
            tlp1.RowCount = 3;
            tlp1.RowStyles.Add(new RowStyle(SizeType.Percent, 4F));
            tlp1.RowStyles.Add(new RowStyle(SizeType.Percent, 4F));
            tlp1.RowStyles.Add(new RowStyle(SizeType.Percent, 92F));
            tlp1.Size = new Size(1140, 1124);
            tlp1.TabIndex = 1;
            // 
            // tlp2
            // 
            tlp2.BackColor = SystemColors.Control;
            tlp2.ColumnCount = 1;
            tlp2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlp2.Controls.Add(tableLayoutPanel2, 0, 2);
            tlp2.Controls.Add(label1, 0, 0);
            tlp2.Controls.Add(tableLayoutPanel1, 0, 1);
            tlp2.Controls.Add(tlpTarjeta, 0, 3);
            tlp2.Dock = DockStyle.Fill;
            tlp2.Location = new Point(0, 88);
            tlp2.Margin = new Padding(0);
            tlp2.Name = "tlp2";
            tlp2.RowCount = 4;
            tlp2.RowStyles.Add(new RowStyle(SizeType.Percent, 10F));
            tlp2.RowStyles.Add(new RowStyle(SizeType.Percent, 10F));
            tlp2.RowStyles.Add(new RowStyle(SizeType.Percent, 40F));
            tlp2.RowStyles.Add(new RowStyle(SizeType.Percent, 40F));
            tlp2.Size = new Size(1140, 1036);
            tlp2.TabIndex = 2;
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 4;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tableLayoutPanel2.Controls.Add(tlp_serviciosEspeciales, 3, 0);
            tableLayoutPanel2.Controls.Add(tlp_reparacion, 2, 0);
            tableLayoutPanel2.Controls.Add(tlp_mantenimiento, 1, 0);
            tableLayoutPanel2.Controls.Add(tlp_lavadoDetallado, 0, 0);
            tableLayoutPanel2.Dock = DockStyle.Fill;
            tableLayoutPanel2.Location = new Point(20, 206);
            tableLayoutPanel2.Margin = new Padding(20, 0, 20, 0);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 1;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel2.Size = new Size(1100, 414);
            tableLayoutPanel2.TabIndex = 2;
            // 
            // tlp_serviciosEspeciales
            // 
            tlp_serviciosEspeciales.BackColor = Color.FromArgb(0, 64, 64);
            tlp_serviciosEspeciales.ColumnCount = 1;
            tlp_serviciosEspeciales.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlp_serviciosEspeciales.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tlp_serviciosEspeciales.Controls.Add(button24, 0, 0);
            tlp_serviciosEspeciales.Controls.Add(button25, 0, 1);
            tlp_serviciosEspeciales.Controls.Add(button26, 0, 2);
            tlp_serviciosEspeciales.Controls.Add(button27, 0, 3);
            tlp_serviciosEspeciales.Controls.Add(button28, 0, 4);
            tlp_serviciosEspeciales.Controls.Add(button29, 0, 5);
            tlp_serviciosEspeciales.Dock = DockStyle.Fill;
            tlp_serviciosEspeciales.Location = new Point(830, 0);
            tlp_serviciosEspeciales.Margin = new Padding(5, 0, 5, 5);
            tlp_serviciosEspeciales.Name = "tlp_serviciosEspeciales";
            tlp_serviciosEspeciales.RowCount = 6;
            tlp_serviciosEspeciales.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            tlp_serviciosEspeciales.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            tlp_serviciosEspeciales.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            tlp_serviciosEspeciales.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            tlp_serviciosEspeciales.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            tlp_serviciosEspeciales.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            tlp_serviciosEspeciales.Size = new Size(265, 409);
            tlp_serviciosEspeciales.TabIndex = 3;
            // 
            // button24
            // 
            button24.BackColor = Color.FromArgb(117, 230, 164);
            button24.Dock = DockStyle.Fill;
            button24.FlatAppearance.BorderColor = Color.White;
            button24.FlatAppearance.BorderSize = 3;
            button24.FlatStyle = FlatStyle.Flat;
            button24.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            button24.ForeColor = Color.FromArgb(0, 64, 64);
            button24.Location = new Point(10, 10);
            button24.Margin = new Padding(10);
            button24.Name = "button24";
            button24.Size = new Size(245, 48);
            button24.TabIndex = 0;
            button24.Text = "Servicio ITV";
            button24.UseVisualStyleBackColor = false;
            button24.Click += servicioItem_Click;
            // 
            // button25
            // 
            button25.BackColor = Color.FromArgb(117, 230, 164);
            button25.Dock = DockStyle.Fill;
            button25.FlatAppearance.BorderColor = Color.White;
            button25.FlatAppearance.BorderSize = 3;
            button25.FlatStyle = FlatStyle.Flat;
            button25.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            button25.ForeColor = Color.FromArgb(0, 64, 64);
            button25.Location = new Point(10, 78);
            button25.Margin = new Padding(10);
            button25.Name = "button25";
            button25.Size = new Size(245, 48);
            button25.TabIndex = 1;
            button25.Text = "Instalación de GPS";
            button25.UseVisualStyleBackColor = false;
            button25.Click += servicioItem_Click;
            // 
            // button26
            // 
            button26.BackColor = Color.FromArgb(117, 230, 164);
            button26.Dock = DockStyle.Fill;
            button26.FlatAppearance.BorderColor = Color.White;
            button26.FlatAppearance.BorderSize = 3;
            button26.FlatStyle = FlatStyle.Flat;
            button26.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            button26.ForeColor = Color.FromArgb(0, 64, 64);
            button26.Location = new Point(10, 146);
            button26.Margin = new Padding(10);
            button26.Name = "button26";
            button26.Size = new Size(245, 48);
            button26.TabIndex = 2;
            button26.Text = "Diagnóstico de motor";
            button26.UseVisualStyleBackColor = false;
            button26.Click += servicioItem_Click;
            // 
            // button27
            // 
            button27.BackColor = Color.FromArgb(117, 230, 164);
            button27.Dock = DockStyle.Fill;
            button27.FlatAppearance.BorderColor = Color.White;
            button27.FlatAppearance.BorderSize = 3;
            button27.FlatStyle = FlatStyle.Flat;
            button27.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            button27.ForeColor = Color.FromArgb(0, 64, 64);
            button27.Location = new Point(10, 214);
            button27.Margin = new Padding(10);
            button27.Name = "button27";
            button27.Size = new Size(245, 48);
            button27.TabIndex = 3;
            button27.Text = "Reparación de la radio";
            button27.UseVisualStyleBackColor = false;
            button27.Click += servicioItem_Click;
            // 
            // button28
            // 
            button28.BackColor = Color.FromArgb(117, 230, 164);
            button28.Dock = DockStyle.Fill;
            button28.FlatAppearance.BorderColor = Color.White;
            button28.FlatAppearance.BorderSize = 3;
            button28.FlatStyle = FlatStyle.Flat;
            button28.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            button28.ForeColor = Color.FromArgb(0, 64, 64);
            button28.Location = new Point(10, 282);
            button28.Margin = new Padding(10);
            button28.Name = "button28";
            button28.Size = new Size(245, 48);
            button28.TabIndex = 4;
            button28.Text = "Tuning y Personalización";
            button28.UseVisualStyleBackColor = false;
            button28.Click += servicioItem_Click;
            // 
            // button29
            // 
            button29.BackColor = Color.FromArgb(117, 230, 164);
            button29.Dock = DockStyle.Fill;
            button29.FlatAppearance.BorderColor = Color.White;
            button29.FlatAppearance.BorderSize = 3;
            button29.FlatStyle = FlatStyle.Flat;
            button29.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            button29.ForeColor = Color.FromArgb(0, 64, 64);
            button29.Location = new Point(10, 350);
            button29.Margin = new Padding(10);
            button29.Name = "button29";
            button29.Size = new Size(245, 49);
            button29.TabIndex = 5;
            button29.Text = "Instalación de Kit LED";
            button29.UseVisualStyleBackColor = false;
            button29.Click += servicioItem_Click;
            // 
            // tlp_reparacion
            // 
            tlp_reparacion.BackColor = Color.FromArgb(0, 64, 64);
            tlp_reparacion.ColumnCount = 1;
            tlp_reparacion.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlp_reparacion.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tlp_reparacion.Controls.Add(button18, 0, 0);
            tlp_reparacion.Controls.Add(button19, 0, 1);
            tlp_reparacion.Controls.Add(button20, 0, 2);
            tlp_reparacion.Controls.Add(button21, 0, 3);
            tlp_reparacion.Controls.Add(button22, 0, 4);
            tlp_reparacion.Controls.Add(button23, 0, 5);
            tlp_reparacion.Dock = DockStyle.Fill;
            tlp_reparacion.Location = new Point(555, 0);
            tlp_reparacion.Margin = new Padding(5, 0, 5, 5);
            tlp_reparacion.Name = "tlp_reparacion";
            tlp_reparacion.RowCount = 6;
            tlp_reparacion.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            tlp_reparacion.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            tlp_reparacion.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            tlp_reparacion.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            tlp_reparacion.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            tlp_reparacion.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            tlp_reparacion.Size = new Size(265, 409);
            tlp_reparacion.TabIndex = 2;
            // 
            // button18
            // 
            button18.BackColor = Color.FromArgb(117, 230, 164);
            button18.Dock = DockStyle.Fill;
            button18.FlatAppearance.BorderColor = Color.White;
            button18.FlatAppearance.BorderSize = 3;
            button18.FlatStyle = FlatStyle.Flat;
            button18.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            button18.ForeColor = Color.FromArgb(0, 64, 64);
            button18.Location = new Point(10, 10);
            button18.Margin = new Padding(10);
            button18.Name = "button18";
            button18.Size = new Size(245, 48);
            button18.TabIndex = 0;
            button18.Text = "Reparación de Frenos";
            button18.UseVisualStyleBackColor = false;
            button18.Click += servicioItem_Click;
            // 
            // button19
            // 
            button19.BackColor = Color.FromArgb(117, 230, 164);
            button19.Dock = DockStyle.Fill;
            button19.FlatAppearance.BorderColor = Color.White;
            button19.FlatAppearance.BorderSize = 3;
            button19.FlatStyle = FlatStyle.Flat;
            button19.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            button19.ForeColor = Color.FromArgb(0, 64, 64);
            button19.Location = new Point(10, 78);
            button19.Margin = new Padding(10);
            button19.Name = "button19";
            button19.Size = new Size(245, 48);
            button19.TabIndex = 1;
            button19.Text = "Reparación de Suspensión";
            button19.UseVisualStyleBackColor = false;
            button19.Click += servicioItem_Click;
            // 
            // button20
            // 
            button20.BackColor = Color.FromArgb(117, 230, 164);
            button20.Dock = DockStyle.Fill;
            button20.FlatAppearance.BorderColor = Color.White;
            button20.FlatAppearance.BorderSize = 3;
            button20.FlatStyle = FlatStyle.Flat;
            button20.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            button20.ForeColor = Color.FromArgb(0, 64, 64);
            button20.Location = new Point(10, 146);
            button20.Margin = new Padding(10);
            button20.Name = "button20";
            button20.Size = new Size(245, 48);
            button20.TabIndex = 2;
            button20.Text = "Reparación de Sistema Eléctrico";
            button20.UseVisualStyleBackColor = false;
            button20.Click += servicioItem_Click;
            // 
            // button21
            // 
            button21.BackColor = Color.FromArgb(117, 230, 164);
            button21.Dock = DockStyle.Fill;
            button21.FlatAppearance.BorderColor = Color.White;
            button21.FlatAppearance.BorderSize = 3;
            button21.FlatStyle = FlatStyle.Flat;
            button21.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            button21.ForeColor = Color.FromArgb(0, 64, 64);
            button21.Location = new Point(10, 214);
            button21.Margin = new Padding(10);
            button21.Name = "button21";
            button21.Size = new Size(245, 48);
            button21.TabIndex = 3;
            button21.Text = "Reparación Dirección Asistida";
            button21.UseVisualStyleBackColor = false;
            button21.Click += servicioItem_Click;
            // 
            // button22
            // 
            button22.BackColor = Color.FromArgb(117, 230, 164);
            button22.Dock = DockStyle.Fill;
            button22.FlatAppearance.BorderColor = Color.White;
            button22.FlatAppearance.BorderSize = 3;
            button22.FlatStyle = FlatStyle.Flat;
            button22.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            button22.ForeColor = Color.FromArgb(0, 64, 64);
            button22.Location = new Point(10, 282);
            button22.Margin = new Padding(10);
            button22.Name = "button22";
            button22.Size = new Size(245, 48);
            button22.TabIndex = 4;
            button22.Text = "Cambio de Correa ";
            button22.UseVisualStyleBackColor = false;
            button22.Click += servicioItem_Click;
            // 
            // button23
            // 
            button23.BackColor = Color.FromArgb(117, 230, 164);
            button23.Dock = DockStyle.Fill;
            button23.FlatAppearance.BorderColor = Color.White;
            button23.FlatAppearance.BorderSize = 3;
            button23.FlatStyle = FlatStyle.Flat;
            button23.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            button23.ForeColor = Color.FromArgb(0, 64, 64);
            button23.Location = new Point(10, 350);
            button23.Margin = new Padding(10);
            button23.Name = "button23";
            button23.Size = new Size(245, 49);
            button23.TabIndex = 5;
            button23.Text = "Reparación de Transmisión";
            button23.UseVisualStyleBackColor = false;
            button23.Click += servicioItem_Click;
            // 
            // tlp_mantenimiento
            // 
            tlp_mantenimiento.BackColor = Color.FromArgb(0, 64, 64);
            tlp_mantenimiento.ColumnCount = 1;
            tlp_mantenimiento.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlp_mantenimiento.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tlp_mantenimiento.Controls.Add(button12, 0, 0);
            tlp_mantenimiento.Controls.Add(button13, 0, 1);
            tlp_mantenimiento.Controls.Add(button14, 0, 2);
            tlp_mantenimiento.Controls.Add(button15, 0, 3);
            tlp_mantenimiento.Controls.Add(button16, 0, 4);
            tlp_mantenimiento.Controls.Add(button17, 0, 5);
            tlp_mantenimiento.Dock = DockStyle.Fill;
            tlp_mantenimiento.Location = new Point(280, 0);
            tlp_mantenimiento.Margin = new Padding(5, 0, 5, 5);
            tlp_mantenimiento.Name = "tlp_mantenimiento";
            tlp_mantenimiento.RowCount = 6;
            tlp_mantenimiento.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            tlp_mantenimiento.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            tlp_mantenimiento.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            tlp_mantenimiento.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            tlp_mantenimiento.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            tlp_mantenimiento.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            tlp_mantenimiento.Size = new Size(265, 409);
            tlp_mantenimiento.TabIndex = 1;
            // 
            // button12
            // 
            button12.BackColor = Color.FromArgb(117, 230, 164);
            button12.Dock = DockStyle.Fill;
            button12.FlatAppearance.BorderColor = Color.White;
            button12.FlatAppearance.BorderSize = 3;
            button12.FlatStyle = FlatStyle.Flat;
            button12.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            button12.ForeColor = Color.FromArgb(0, 64, 64);
            button12.Location = new Point(10, 10);
            button12.Margin = new Padding(10);
            button12.Name = "button12";
            button12.Size = new Size(245, 48);
            button12.TabIndex = 0;
            button12.Text = "Cambio de Aceite y Filtro";
            button12.UseVisualStyleBackColor = false;
            button12.Click += servicioItem_Click;
            // 
            // button13
            // 
            button13.BackColor = Color.FromArgb(117, 230, 164);
            button13.Dock = DockStyle.Fill;
            button13.FlatAppearance.BorderColor = Color.White;
            button13.FlatAppearance.BorderSize = 3;
            button13.FlatStyle = FlatStyle.Flat;
            button13.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            button13.ForeColor = Color.FromArgb(0, 64, 64);
            button13.Location = new Point(10, 78);
            button13.Margin = new Padding(10);
            button13.Name = "button13";
            button13.Size = new Size(245, 48);
            button13.TabIndex = 1;
            button13.Text = "Alineación y Balanceo";
            button13.UseVisualStyleBackColor = false;
            button13.Click += servicioItem_Click;
            // 
            // button14
            // 
            button14.BackColor = Color.FromArgb(117, 230, 164);
            button14.Dock = DockStyle.Fill;
            button14.FlatAppearance.BorderColor = Color.White;
            button14.FlatAppearance.BorderSize = 3;
            button14.FlatStyle = FlatStyle.Flat;
            button14.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            button14.ForeColor = Color.FromArgb(0, 64, 64);
            button14.Location = new Point(10, 146);
            button14.Margin = new Padding(10);
            button14.Name = "button14";
            button14.Size = new Size(245, 48);
            button14.TabIndex = 2;
            button14.Text = "Revisión Completa";
            button14.UseVisualStyleBackColor = false;
            button14.Click += servicioItem_Click;
            // 
            // button15
            // 
            button15.BackColor = Color.FromArgb(117, 230, 164);
            button15.Dock = DockStyle.Fill;
            button15.FlatAppearance.BorderColor = Color.White;
            button15.FlatAppearance.BorderSize = 3;
            button15.FlatStyle = FlatStyle.Flat;
            button15.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            button15.ForeColor = Color.FromArgb(0, 64, 64);
            button15.Location = new Point(10, 214);
            button15.Margin = new Padding(10);
            button15.Name = "button15";
            button15.Size = new Size(245, 48);
            button15.TabIndex = 3;
            button15.Text = "Cambio de Batería";
            button15.UseVisualStyleBackColor = false;
            button15.Click += servicioItem_Click;
            // 
            // button16
            // 
            button16.BackColor = Color.FromArgb(117, 230, 164);
            button16.Dock = DockStyle.Fill;
            button16.FlatAppearance.BorderColor = Color.White;
            button16.FlatAppearance.BorderSize = 3;
            button16.FlatStyle = FlatStyle.Flat;
            button16.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            button16.ForeColor = Color.FromArgb(0, 64, 64);
            button16.Location = new Point(10, 282);
            button16.Margin = new Padding(10);
            button16.Name = "button16";
            button16.Size = new Size(245, 48);
            button16.TabIndex = 4;
            button16.Text = "Cambio de neumáticos";
            button16.UseVisualStyleBackColor = false;
            button16.Click += servicioItem_Click;
            // 
            // button17
            // 
            button17.BackColor = Color.FromArgb(117, 230, 164);
            button17.Dock = DockStyle.Fill;
            button17.FlatAppearance.BorderColor = Color.White;
            button17.FlatAppearance.BorderSize = 3;
            button17.FlatStyle = FlatStyle.Flat;
            button17.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            button17.ForeColor = Color.FromArgb(0, 64, 64);
            button17.Location = new Point(10, 350);
            button17.Margin = new Padding(10);
            button17.Name = "button17";
            button17.Size = new Size(245, 49);
            button17.TabIndex = 5;
            button17.Text = "Cambio de Pastillas de Freno";
            button17.UseVisualStyleBackColor = false;
            button17.Click += servicioItem_Click;
            // 
            // tlp_lavadoDetallado
            // 
            tlp_lavadoDetallado.BackColor = Color.FromArgb(0, 64, 64);
            tlp_lavadoDetallado.ColumnCount = 1;
            tlp_lavadoDetallado.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlp_lavadoDetallado.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tlp_lavadoDetallado.Controls.Add(button6, 0, 0);
            tlp_lavadoDetallado.Controls.Add(button7, 0, 1);
            tlp_lavadoDetallado.Controls.Add(button8, 0, 2);
            tlp_lavadoDetallado.Controls.Add(button9, 0, 3);
            tlp_lavadoDetallado.Controls.Add(button10, 0, 4);
            tlp_lavadoDetallado.Controls.Add(button11, 0, 5);
            tlp_lavadoDetallado.Dock = DockStyle.Fill;
            tlp_lavadoDetallado.Location = new Point(5, 0);
            tlp_lavadoDetallado.Margin = new Padding(5, 0, 5, 5);
            tlp_lavadoDetallado.Name = "tlp_lavadoDetallado";
            tlp_lavadoDetallado.RowCount = 6;
            tlp_lavadoDetallado.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            tlp_lavadoDetallado.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            tlp_lavadoDetallado.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            tlp_lavadoDetallado.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            tlp_lavadoDetallado.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            tlp_lavadoDetallado.RowStyles.Add(new RowStyle(SizeType.Percent, 16.6666641F));
            tlp_lavadoDetallado.Size = new Size(265, 409);
            tlp_lavadoDetallado.TabIndex = 0;
            // 
            // button6
            // 
            button6.BackColor = Color.FromArgb(117, 230, 164);
            button6.Dock = DockStyle.Fill;
            button6.FlatAppearance.BorderColor = Color.White;
            button6.FlatAppearance.BorderSize = 3;
            button6.FlatStyle = FlatStyle.Flat;
            button6.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            button6.ForeColor = Color.FromArgb(0, 64, 64);
            button6.Location = new Point(10, 10);
            button6.Margin = new Padding(10);
            button6.Name = "button6";
            button6.Size = new Size(245, 48);
            button6.TabIndex = 0;
            button6.Text = "Lavado Exterior";
            button6.UseVisualStyleBackColor = false;
            button6.Click += servicioItem_Click;
            // 
            // button7
            // 
            button7.BackColor = Color.FromArgb(117, 230, 164);
            button7.Dock = DockStyle.Fill;
            button7.FlatAppearance.BorderColor = Color.White;
            button7.FlatAppearance.BorderSize = 3;
            button7.FlatStyle = FlatStyle.Flat;
            button7.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            button7.ForeColor = Color.FromArgb(0, 64, 64);
            button7.Location = new Point(10, 78);
            button7.Margin = new Padding(10);
            button7.Name = "button7";
            button7.Size = new Size(245, 48);
            button7.TabIndex = 1;
            button7.Text = "Lavado de Motor";
            button7.UseVisualStyleBackColor = false;
            button7.Click += servicioItem_Click;
            // 
            // button8
            // 
            button8.BackColor = Color.FromArgb(117, 230, 164);
            button8.Dock = DockStyle.Fill;
            button8.FlatAppearance.BorderColor = Color.White;
            button8.FlatAppearance.BorderSize = 3;
            button8.FlatStyle = FlatStyle.Flat;
            button8.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            button8.ForeColor = Color.FromArgb(0, 64, 64);
            button8.Location = new Point(10, 146);
            button8.Margin = new Padding(10);
            button8.Name = "button8";
            button8.Size = new Size(245, 48);
            button8.TabIndex = 2;
            button8.Text = "Lavado de Llantas";
            button8.UseVisualStyleBackColor = false;
            button8.Click += servicioItem_Click;
            // 
            // button9
            // 
            button9.BackColor = Color.FromArgb(117, 230, 164);
            button9.Dock = DockStyle.Fill;
            button9.FlatAppearance.BorderColor = Color.White;
            button9.FlatAppearance.BorderSize = 3;
            button9.FlatStyle = FlatStyle.Flat;
            button9.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            button9.ForeColor = Color.FromArgb(0, 64, 64);
            button9.Location = new Point(10, 214);
            button9.Margin = new Padding(10);
            button9.Name = "button9";
            button9.Size = new Size(245, 48);
            button9.TabIndex = 3;
            button9.Text = "Limpieza de Tapicería";
            button9.UseVisualStyleBackColor = false;
            button9.Click += servicioItem_Click;
            // 
            // button10
            // 
            button10.BackColor = Color.FromArgb(117, 230, 164);
            button10.Dock = DockStyle.Fill;
            button10.FlatAppearance.BorderColor = Color.White;
            button10.FlatAppearance.BorderSize = 3;
            button10.FlatStyle = FlatStyle.Flat;
            button10.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            button10.ForeColor = Color.FromArgb(0, 64, 64);
            button10.Location = new Point(10, 282);
            button10.Margin = new Padding(10);
            button10.Name = "button10";
            button10.Size = new Size(245, 48);
            button10.TabIndex = 4;
            button10.Text = "Encerado Profundo";
            button10.UseVisualStyleBackColor = false;
            button10.Click += servicioItem_Click;
            // 
            // button11
            // 
            button11.BackColor = Color.FromArgb(117, 230, 164);
            button11.Dock = DockStyle.Fill;
            button11.FlatAppearance.BorderColor = Color.White;
            button11.FlatAppearance.BorderSize = 3;
            button11.FlatStyle = FlatStyle.Flat;
            button11.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            button11.ForeColor = Color.FromArgb(0, 64, 64);
            button11.Location = new Point(10, 350);
            button11.Margin = new Padding(10);
            button11.Name = "button11";
            button11.Size = new Size(245, 49);
            button11.TabIndex = 5;
            button11.Text = "Pulido de Faros";
            button11.UseVisualStyleBackColor = false;
            button11.Click += servicioItem_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Dock = DockStyle.Fill;
            label1.Font = new Font("Cooper Black", 30F);
            label1.ForeColor = Color.FromArgb(39, 50, 56);
            label1.Location = new Point(3, 0);
            label1.Name = "label1";
            label1.Size = new Size(1134, 103);
            label1.TabIndex = 0;
            label1.Text = "¿Qué clase de servicio buscas?";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 4;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.Controls.Add(button1, 0, 0);
            tableLayoutPanel1.Controls.Add(button2, 1, 0);
            tableLayoutPanel1.Controls.Add(button3, 2, 0);
            tableLayoutPanel1.Controls.Add(button4, 3, 0);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(20, 103);
            tableLayoutPanel1.Margin = new Padding(20, 0, 20, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.Size = new Size(1100, 103);
            tableLayoutPanel1.TabIndex = 1;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(0, 64, 64);
            button1.Dock = DockStyle.Fill;
            button1.FlatAppearance.BorderColor = Color.White;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Cooper Black", 13F);
            button1.ForeColor = Color.White;
            button1.Location = new Point(5, 5);
            button1.Margin = new Padding(5, 5, 5, 0);
            button1.Name = "button1";
            button1.Size = new Size(265, 98);
            button1.TabIndex = 0;
            button1.Text = "Lavado y Detallado";
            toolTip1.SetToolTip(button1, "Familia de servicios 'Lavado y Detallado'");
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(0, 64, 64);
            button2.Dock = DockStyle.Fill;
            button2.FlatAppearance.BorderColor = Color.White;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Cooper Black", 13F);
            button2.ForeColor = Color.White;
            button2.Location = new Point(280, 5);
            button2.Margin = new Padding(5, 5, 5, 0);
            button2.Name = "button2";
            button2.Size = new Size(265, 98);
            button2.TabIndex = 1;
            button2.Text = "Mantenimiento";
            toolTip1.SetToolTip(button2, "Familia de servicios 'Mantenimiento'");
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(0, 64, 64);
            button3.Dock = DockStyle.Fill;
            button3.FlatAppearance.BorderColor = Color.White;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Cooper Black", 13F);
            button3.ForeColor = Color.White;
            button3.Location = new Point(555, 5);
            button3.Margin = new Padding(5, 5, 5, 0);
            button3.Name = "button3";
            button3.Size = new Size(265, 98);
            button3.TabIndex = 2;
            button3.Text = "Reparación";
            toolTip1.SetToolTip(button3, "Familia de servicios 'Reparación'");
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(0, 64, 64);
            button4.Dock = DockStyle.Fill;
            button4.FlatAppearance.BorderColor = Color.White;
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Cooper Black", 13F);
            button4.ForeColor = Color.White;
            button4.Location = new Point(830, 5);
            button4.Margin = new Padding(5, 5, 5, 0);
            button4.Name = "button4";
            button4.Size = new Size(265, 98);
            button4.TabIndex = 3;
            button4.Text = "Servicios Especiales";
            toolTip1.SetToolTip(button4, "Familia de servicios 'Servicios Especiales'");
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // tlpTarjeta
            // 
            tlpTarjeta.ColumnCount = 2;
            tlpTarjeta.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30F));
            tlpTarjeta.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 70F));
            tlpTarjeta.Controls.Add(tableLayoutPanel7, 1, 0);
            tlpTarjeta.Controls.Add(pboxFamilia, 0, 0);
            tlpTarjeta.Dock = DockStyle.Fill;
            tlpTarjeta.Location = new Point(25, 650);
            tlpTarjeta.Margin = new Padding(25, 30, 25, 40);
            tlpTarjeta.Name = "tlpTarjeta";
            tlpTarjeta.RowCount = 1;
            tlpTarjeta.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tlpTarjeta.Size = new Size(1090, 346);
            tlpTarjeta.TabIndex = 3;
            // 
            // tableLayoutPanel7
            // 
            tableLayoutPanel7.ColumnCount = 1;
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tableLayoutPanel7.Controls.Add(tableLayoutPanel8, 0, 0);
            tableLayoutPanel7.Controls.Add(button5, 0, 1);
            tableLayoutPanel7.Dock = DockStyle.Fill;
            tableLayoutPanel7.Location = new Point(327, 0);
            tableLayoutPanel7.Margin = new Padding(0);
            tableLayoutPanel7.Name = "tableLayoutPanel7";
            tableLayoutPanel7.RowCount = 2;
            tableLayoutPanel7.RowStyles.Add(new RowStyle(SizeType.Percent, 83.33F));
            tableLayoutPanel7.RowStyles.Add(new RowStyle(SizeType.Percent, 16.67F));
            tableLayoutPanel7.Size = new Size(763, 346);
            tableLayoutPanel7.TabIndex = 4;
            // 
            // tableLayoutPanel8
            // 
            tableLayoutPanel8.ColumnCount = 2;
            tableLayoutPanel8.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 35F));
            tableLayoutPanel8.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 65F));
            tableLayoutPanel8.Controls.Add(label2, 0, 0);
            tableLayoutPanel8.Controls.Add(label3, 0, 1);
            tableLayoutPanel8.Controls.Add(label4, 0, 2);
            tableLayoutPanel8.Controls.Add(label5, 0, 3);
            tableLayoutPanel8.Controls.Add(labelSE_Servicio, 1, 0);
            tableLayoutPanel8.Controls.Add(labelSE_Taller, 1, 1);
            tableLayoutPanel8.Controls.Add(labelSE_ImporteBruto, 1, 2);
            tableLayoutPanel8.Controls.Add(labelSE_TipoImpositivo, 1, 3);
            tableLayoutPanel8.Dock = DockStyle.Fill;
            tableLayoutPanel8.Location = new Point(0, 0);
            tableLayoutPanel8.Margin = new Padding(0);
            tableLayoutPanel8.Name = "tableLayoutPanel8";
            tableLayoutPanel8.RowCount = 4;
            tableLayoutPanel8.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanel8.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanel8.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanel8.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanel8.Size = new Size(763, 288);
            tableLayoutPanel8.TabIndex = 0;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.FromArgb(117, 230, 164);
            label2.CausesValidation = false;
            label2.Dock = DockStyle.Fill;
            label2.Font = new Font("Cooper Black", 11F);
            label2.ForeColor = Color.FromArgb(39, 50, 56);
            label2.Location = new Point(0, 0);
            label2.Margin = new Padding(0);
            label2.Name = "label2";
            label2.Size = new Size(267, 72);
            label2.TabIndex = 0;
            label2.Text = "Servicio";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            toolTip1.SetToolTip(label2, "Nombre del servicio a contratar");
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.FromArgb(117, 230, 164);
            label3.CausesValidation = false;
            label3.Dock = DockStyle.Fill;
            label3.Font = new Font("Cooper Black", 11F);
            label3.ForeColor = Color.FromArgb(39, 50, 56);
            label3.Location = new Point(0, 72);
            label3.Margin = new Padding(0);
            label3.Name = "label3";
            label3.Size = new Size(267, 72);
            label3.TabIndex = 1;
            label3.Text = "Taller";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            toolTip1.SetToolTip(label3, "El servicio tiene lugar en un taller concreto");
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.FromArgb(117, 230, 164);
            label4.CausesValidation = false;
            label4.Dock = DockStyle.Fill;
            label4.Font = new Font("Cooper Black", 11F);
            label4.ForeColor = Color.FromArgb(39, 50, 56);
            label4.Location = new Point(0, 144);
            label4.Margin = new Padding(0);
            label4.Name = "label4";
            label4.Size = new Size(267, 72);
            label4.TabIndex = 2;
            label4.Text = "Importe bruto";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            toolTip1.SetToolTip(label4, "Importe bruto, antes de impuestos");
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.FromArgb(117, 230, 164);
            label5.CausesValidation = false;
            label5.Dock = DockStyle.Fill;
            label5.Font = new Font("Cooper Black", 11F);
            label5.ForeColor = Color.FromArgb(39, 50, 56);
            label5.Location = new Point(0, 216);
            label5.Margin = new Padding(0);
            label5.Name = "label5";
            label5.Size = new Size(267, 72);
            label5.TabIndex = 3;
            label5.Text = "Tipo impositivo";
            label5.TextAlign = ContentAlignment.MiddleCenter;
            toolTip1.SetToolTip(label5, "Tipo impositivo ampliado");
            // 
            // labelSE_Servicio
            // 
            labelSE_Servicio.AutoSize = true;
            labelSE_Servicio.BackColor = Color.White;
            labelSE_Servicio.Dock = DockStyle.Fill;
            labelSE_Servicio.Location = new Point(267, 0);
            labelSE_Servicio.Margin = new Padding(0);
            labelSE_Servicio.Name = "labelSE_Servicio";
            labelSE_Servicio.Padding = new Padding(30, 0, 0, 0);
            labelSE_Servicio.Size = new Size(496, 72);
            labelSE_Servicio.TabIndex = 5;
            labelSE_Servicio.Text = "...";
            labelSE_Servicio.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // labelSE_Taller
            // 
            labelSE_Taller.AutoSize = true;
            labelSE_Taller.BackColor = Color.White;
            labelSE_Taller.Dock = DockStyle.Fill;
            labelSE_Taller.Location = new Point(267, 72);
            labelSE_Taller.Margin = new Padding(0);
            labelSE_Taller.Name = "labelSE_Taller";
            labelSE_Taller.Padding = new Padding(30, 0, 0, 0);
            labelSE_Taller.Size = new Size(496, 72);
            labelSE_Taller.TabIndex = 6;
            labelSE_Taller.Text = "...";
            labelSE_Taller.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // labelSE_ImporteBruto
            // 
            labelSE_ImporteBruto.AutoSize = true;
            labelSE_ImporteBruto.BackColor = Color.White;
            labelSE_ImporteBruto.Dock = DockStyle.Fill;
            labelSE_ImporteBruto.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            labelSE_ImporteBruto.Location = new Point(267, 144);
            labelSE_ImporteBruto.Margin = new Padding(0);
            labelSE_ImporteBruto.Name = "labelSE_ImporteBruto";
            labelSE_ImporteBruto.Padding = new Padding(30, 0, 0, 0);
            labelSE_ImporteBruto.Size = new Size(496, 72);
            labelSE_ImporteBruto.TabIndex = 7;
            labelSE_ImporteBruto.Text = "...";
            labelSE_ImporteBruto.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // labelSE_TipoImpositivo
            // 
            labelSE_TipoImpositivo.AutoSize = true;
            labelSE_TipoImpositivo.BackColor = Color.White;
            labelSE_TipoImpositivo.Dock = DockStyle.Fill;
            labelSE_TipoImpositivo.Location = new Point(267, 216);
            labelSE_TipoImpositivo.Margin = new Padding(0);
            labelSE_TipoImpositivo.Name = "labelSE_TipoImpositivo";
            labelSE_TipoImpositivo.Padding = new Padding(30, 0, 0, 0);
            labelSE_TipoImpositivo.Size = new Size(496, 72);
            labelSE_TipoImpositivo.TabIndex = 8;
            labelSE_TipoImpositivo.Text = "...";
            labelSE_TipoImpositivo.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // button5
            // 
            button5.BackColor = Color.FromArgb(0, 64, 64);
            button5.Dock = DockStyle.Fill;
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Cooper Black", 15F);
            button5.ForeColor = Color.White;
            button5.Location = new Point(0, 288);
            button5.Margin = new Padding(0);
            button5.Name = "button5";
            button5.Size = new Size(763, 58);
            button5.TabIndex = 1;
            button5.Text = "CONTINUAR";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click_1;
            // 
            // pboxFamilia
            // 
            pboxFamilia.BackColor = Color.HotPink;
            pboxFamilia.Dock = DockStyle.Fill;
            pboxFamilia.Location = new Point(0, 0);
            pboxFamilia.Margin = new Padding(0);
            pboxFamilia.Name = "pboxFamilia";
            pboxFamilia.Size = new Size(327, 346);
            pboxFamilia.TabIndex = 5;
            pboxFamilia.TabStop = false;
            // 
            // btn_salir
            // 
            btn_salir.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btn_salir.BackColor = Color.FromArgb(117, 230, 164);
            btn_salir.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btn_salir.ForeColor = Color.White;
            btn_salir.Location = new Point(1098, 3);
            btn_salir.Name = "btn_salir";
            btn_salir.Size = new Size(39, 38);
            btn_salir.TabIndex = 1;
            btn_salir.Text = "X";
            btn_salir.UseVisualStyleBackColor = false;
            btn_salir.Click += btn_salir_Click;
            // 
            // tableLayoutPanel3
            // 
            tableLayoutPanel3.ColumnCount = 2;
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 15F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 85F));
            tableLayoutPanel3.Controls.Add(label_nombreUsuario2, 0, 0);
            tableLayoutPanel3.Controls.Add(pictureBox2, 0, 0);
            tableLayoutPanel3.Dock = DockStyle.Fill;
            tableLayoutPanel3.Location = new Point(800, 47);
            tableLayoutPanel3.Margin = new Padding(800, 3, 3, 3);
            tableLayoutPanel3.Name = "tableLayoutPanel3";
            tableLayoutPanel3.RowCount = 1;
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel3.Size = new Size(337, 38);
            tableLayoutPanel3.TabIndex = 3;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.FromArgb(223, 248, 229);
            pictureBox2.BackgroundImage = (Image)resources.GetObject("pictureBox2.BackgroundImage");
            pictureBox2.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox2.Dock = DockStyle.Fill;
            pictureBox2.Location = new Point(0, 0);
            pictureBox2.Margin = new Padding(0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(50, 38);
            pictureBox2.TabIndex = 4;
            pictureBox2.TabStop = false;
            // 
            // label_nombreUsuario2
            // 
            label_nombreUsuario2.AutoSize = true;
            label_nombreUsuario2.Dock = DockStyle.Fill;
            label_nombreUsuario2.Location = new Point(53, 0);
            label_nombreUsuario2.Name = "label_nombreUsuario2";
            label_nombreUsuario2.Size = new Size(281, 38);
            label_nombreUsuario2.TabIndex = 5;
            label_nombreUsuario2.Text = "label6";
            label_nombreUsuario2.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // Form_Cliente
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1140, 1124);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form_Cliente";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            panel1.ResumeLayout(false);
            tlp1.ResumeLayout(false);
            tlp2.ResumeLayout(false);
            tlp2.PerformLayout();
            tableLayoutPanel2.ResumeLayout(false);
            tlp_serviciosEspeciales.ResumeLayout(false);
            tlp_reparacion.ResumeLayout(false);
            tlp_mantenimiento.ResumeLayout(false);
            tlp_lavadoDetallado.ResumeLayout(false);
            tableLayoutPanel1.ResumeLayout(false);
            tlpTarjeta.ResumeLayout(false);
            tableLayoutPanel7.ResumeLayout(false);
            tableLayoutPanel8.ResumeLayout(false);
            tableLayoutPanel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pboxFamilia).EndInit();
            tableLayoutPanel3.ResumeLayout(false);
            tableLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private TableLayoutPanel tlp1;
        private TableLayoutPanel tlp2;
        private Button btn_salir;
        private Label label1;
        private TableLayoutPanel tableLayoutPanel2;
        private TableLayoutPanel tableLayoutPanel1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private TableLayoutPanel tlp_lavadoDetallado;
        private TableLayoutPanel tlp_serviciosEspeciales;
        private TableLayoutPanel tlp_reparacion;
        private TableLayoutPanel tlp_mantenimiento;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button24;
        private Button button25;
        private Button button26;
        private Button button27;
        private Button button28;
        private Button button29;
        private Button button18;
        private Button button19;
        private Button button20;
        private Button button21;
        private Button button22;
        private Button button23;
        private Button button17;
        private TableLayoutPanel tlpTarjeta;
        private TableLayoutPanel tableLayoutPanel7;
        private TableLayoutPanel tableLayoutPanel8;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label labelSE_Servicio;
        private Label labelSE_Taller;
        private Label labelSE_ImporteBruto;
        private Label labelSE_TipoImpositivo;
        private Button button5;
        private PictureBox pboxFamilia;
        private ToolTip toolTip1;
        private TableLayoutPanel tableLayoutPanel3;
        private PictureBox pictureBox2;
        private Label label_nombreUsuario2;
    }
}